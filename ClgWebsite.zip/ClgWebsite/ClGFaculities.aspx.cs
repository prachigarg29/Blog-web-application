﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string dept = "Director";
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select * from [ClgDB].[dbo].[tbl_faculties] where [Department]='"+dept+"'";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        string dept2 = "Faculties of Computer Department";
        string strcmd2 = @"select * from [ClgDB].[dbo].[tbl_faculties] where [Department]='" + dept2 + "'";
        SqlDataAdapter sqlad2 = new SqlDataAdapter(strcmd2, sqlcon);
        DataSet ds2 = new DataSet();
        sqlad2.Fill(ds2);
        if (ds2.Tables[0].Rows.Count > 0)
        {
            GridView2.DataSource = ds2;
            GridView2.DataBind();
        }
        string dept3 = "Faculties of Management Department";
        string strcmd3 = @"select * from [ClgDB].[dbo].[tbl_faculties] where [Department]='" + dept3 + "'";
        SqlDataAdapter sqlad3 = new SqlDataAdapter(strcmd3, sqlcon);
        DataSet ds3 = new DataSet();
        sqlad3.Fill(ds3);
        if (ds3.Tables[0].Rows.Count > 0)
        {
            GridView3.DataSource = ds3;
            GridView3.DataBind();
        }
        string dept4 = "Administrative Staff of the College";
        string strcmd4 = @"select * from [ClgDB].[dbo].[tbl_faculties] where [Department]='" + dept4 + "'";
        SqlDataAdapter sqlad4 = new SqlDataAdapter(strcmd4, sqlcon);
        DataSet ds4 = new DataSet();
        sqlad4.Fill(ds4);
        if (ds4.Tables[0].Rows.Count > 0)
        {
            GridView4.DataSource = ds4;
            GridView4.DataBind();
        }


    }

}