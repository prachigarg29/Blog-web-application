﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //txtEmail.Text = string.Empty;
        //txtpswd.Text = string.Empty;
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string str = @"select * from  [ClgDB].[dbo].[StuTbl] where [StuEmail]='" + txtemail.Text + "' and [StuPswd]='" + txtpswd.Text + "'";
        SqlDataAdapter sqlad = new SqlDataAdapter(str, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            //txtEmail.Text = string.Empty;
            //txtpswd.Text = string.Empty;
            Session.Add("stuname", ds.Tables[0].Rows[0]["StuName"].ToString());
            Session.Add("stupic", ds.Tables[0].Rows[0]["stuPic"].ToString());
            Session.Add("sid", Convert.ToInt64(ds.Tables[0].Rows[0]["StuID"].ToString()));
            Response.Redirect("HomePage.aspx");
        }
    }
}