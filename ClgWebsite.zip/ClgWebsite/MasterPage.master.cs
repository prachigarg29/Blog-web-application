﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class MasterPage : System.Web.UI.MasterPage
{
    long id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        id = Convert.ToInt64(Session["sid"]);
        if (id > 0)
        {
            loginpnl.Visible = false;
            profileshow.Visible = true;
            logoutpnl.Visible = true;
        }
        else
        {
            loginpnl.Visible = true;
            profileshow.Visible = false;
            logoutpnl.Visible = false;
        }


    }

    protected void logout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("login.aspx");
    }
}
