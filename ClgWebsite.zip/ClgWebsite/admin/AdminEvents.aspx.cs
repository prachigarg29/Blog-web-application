﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class admin_AdminEvents : System.Web.UI.Page
{
    long aid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlshow.Visible = true;
        pnladd.Visible = false;
        pnledit.Visible = false;
        if (Request.QueryString.HasKeys())
        {
            if (Request.QueryString["v"].ToString() == "AP")
            {
                pnladd.Visible = true;
                pnlshow.Visible = false;
                pnledit.Visible = false;
            }
            else if (Request.QueryString["v"].ToString() == "EP")
            {
                pnladd.Visible = false;
                pnlshow.Visible = false;
                pnledit.Visible = true;
                aid = Convert.ToInt64(Request.QueryString["i"].ToString());
                getdata();
            }
        }
        bindata();
    }

    public void bindata()
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select [EventId]
      ,[EventName]
      ,EventDes 
      ,[EventDate] from  [ClgDB].[dbo].[tblEvents] ";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataTable dt = new DataTable();
        sqlad.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["EventDes"] = dt.Rows[i]["EventDes"].ToString().Substring(0, 30);
            }
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

    }

    public void getdata()
    {
        if (!IsPostBack)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"select * from  [ClgDB].[dbo].[tblEvents] where [EventId]= " + aid;
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtEname.Text = ds.Tables[0].Rows[0]["EventName"].ToString();
                txtEdate.Text = ds.Tables[0].Rows[0]["EventDate"].ToString();
                txtEdes.Text = ds.Tables[0].Rows[0]["EventDes"].ToString();
            }
        }
    }


    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {
            string strPath = "";
            if (fileuploader.HasFile)
            {
                strPath = "..\\img\\" + fileuploader.FileName;
                string actPath = Server.MapPath(strPath);
                fileuploader.SaveAs(actPath);
            }

            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            using (SqlConnection sqlcon = new SqlConnection(strcon))
            {
                string strcmd = @"INSERT INTO [dbo].[tblEvents]
                                ([EventName]
                                ,[EventDes]
                                ,[EventImg]
                                ,[EventDate])
                            VALUES
                                (@EventName, @EventDes, @EventImg, @EventDate)";
                using (SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon))
                {
                    sqlcmd.Parameters.AddWithValue("@EventName", txtname.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@EventDes", txtdes.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@EventImg", strPath);
                    sqlcmd.Parameters.AddWithValue("@EventDate", txtdate.Text.Trim());

                    sqlcon.Open();
                    if (sqlcmd.ExecuteNonQuery() > 0)
                    {
                        Response.Write("<script>alert('add success...')</script>");
                        txtEname.Text = string.Empty;
                        txtdate.Text = string.Empty;
                        txtdes.Text = string.Empty;
                        Response.Redirect("AdminEvents.aspx");
                    }
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }


    protected void btnUpt_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {
            string strPath = "";
            if (fileupload1.HasFile)
            {
                strPath = "..\\img\\" + fileupload1.FileName;
                string actPath = Server.MapPath(strPath);
                fileupload1.SaveAs(actPath);
            }
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"update [ClgDB].[dbo].[tblEvents] set [EventName]='" + txtEname.Text.Trim() + "',[EventDes]='" + txtEdes.Text.Trim() + "',[EventDate]='" + txtEdate.Text.Trim() + "',[EventImg]='" + strPath + "' where [EventId]= " + aid;
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert(' success...')</script>");
                Response.Redirect("AdminEvents.aspx");
            }

        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            if (e.CommandName == "DEL")
            {
                string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(strcon);
                string strcmd = @"delete from [ClgDB].[dbo].[tblEvents] where [EventId]=" + Convert.ToInt64(e.CommandArgument);
                SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
                sqlcon.Open();
                if (sqlcmd.ExecuteNonQuery() > 0)
                {
                    //Response.Write("<script>alert('deleted successfully ...')</script>");
                    Response.Redirect("AdminEvents.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}