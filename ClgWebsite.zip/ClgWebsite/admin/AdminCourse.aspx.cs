﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class admin_AdminCourse : System.Web.UI.Page
{
    long aid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        bindata();
        pnlshowdata.Visible = true;
        pnladd.Visible = false;
        pnledt.Visible = false;
        if (Request.QueryString.HasKeys())
        {
            if (Request.QueryString["v"].ToString() == "EP")
            {
                pnledt.Visible = true;
                pnlshowdata.Visible = false;
                pnladd.Visible = false;
                aid = Convert.ToInt64(Request.QueryString["i"].ToString());
                getdata();
            }
            else if (Request.QueryString["v"].ToString() == "AP")
            {
                pnladd.Visible = true;
                pnledt.Visible = false;
                pnlshowdata.Visible = false;
            }
        }

    }

    public void getdata()
    {
        if (!IsPostBack)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"select * from [ClgDB].[dbo].[tblcourse] where [CourseID]= " + aid;
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtEcourseName.Text = ds.Tables[0].Rows[0]["CourseName"].ToString();
                txtECourseElegibilty.Text = ds.Tables[0].Rows[0]["CourseElegiblity"].ToString();
                txtEcourseFees.Text = ds.Tables[0].Rows[0]["CourseFees"].ToString();
                txtEMandetoryMarks.Text = ds.Tables[0].Rows[0]["CourseMarksMendartery"].ToString();

                txtEyear.Value = ds.Tables[0].Rows[0]["CourseYear"].ToString();
                txtEcoursedes.Text = ds.Tables[0].Rows[0]["CourseDes"].ToString();
                txtEcourseScope.Text = ds.Tables[0].Rows[0]["CourseScope"].ToString();
                txtEjobs.Text = ds.Tables[0].Rows[0]["CareerForJobsAfterCourse"].ToString();


            }
        }
    }

    public void bindata()
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select * from [ClgDB].[dbo].[tblcourse]";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            if (e.CommandName == "DEL")
            {
                string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(strcon);
                string strcmd = @"delete from [ClgDB].[dbo].[tblcourse]  where [CourseID] =" + Convert.ToInt64(e.CommandArgument);
                SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
                sqlcon.Open();
                if (sqlcmd.ExecuteNonQuery() > 0)
                {
                    //Response.Write("<script>alert('deleted successfully ...')</script>");
                    Response.Redirect("AdminCourse.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        string strPath = "";
        if (fileupload.HasFile)
        {
            strPath = "..\\img\\" + fileupload.FileName;
            string actPath = Server.MapPath(strPath);
            fileupload.SaveAs(actPath);
        }

        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"INSERT INTO [dbo].[tblcourse]
           ([CourseName]
           ,[CourseElegiblity]
           ,[CourseFees]
           ,[CourseMarksMendartery]
           ,[CourseYear]
           ,[CourseDes]
           ,[CourseScope]
           ,[CareerForJobsAfterCourse]
           ,[CourseImg])
     VALUES ('" + txtcourseName.Text.Trim() + "','" + txtCourseElegibilty.Text.Trim() + "','" + txtcourseFees.Text.Trim() + "','" + txtMandetoryMarks.Text.Trim() + "','" + txtyear.Value + "','" + txtcoursedes.Text.Trim() + "','" + txtcourseScope.Text.Trim() + "','" + txtjobs.Text.Trim() + "','" + strPath + "')";
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        if (sqlcmd.ExecuteNonQuery() > 0)
        {
            Response.Write("<script>alert('add success...')</script>");
            Response.Redirect("AdminCourse.aspx");
        }

    }

    protected void BtnUPDATE_Click(object sender, EventArgs e)
    {
        string strPath = "";
        if (fileupload1 .HasFile)
        {
            strPath = "..\\img\\" + fileupload1.FileName;
            string actPath = Server.MapPath(strPath);
            fileupload1.SaveAs(actPath);
        }

        string connectionString = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";

        string query = @"UPDATE [ClgDB].[dbo].[tblcourse] SET [CourseName]=@CourseName, [CourseElegiblity]=@CourseElegiblity, [CourseFees]=@CourseFees, [CourseMarksMendartery]=@CourseMarksMendartery, [CourseYear]=@CourseYear, [CourseDes]=@CourseDes, [CourseScope]=@CourseScope, [CareerForJobsAfterCourse]=@CareerForJobsAfterCourse,[CourseImg]='"+strPath+"' WHERE [CourseID]=@CourseID";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CourseName", txtEcourseName.Text.Trim());
                command.Parameters.AddWithValue("@CourseElegiblity", txtECourseElegibilty.Text.Trim());
                command.Parameters.AddWithValue("@CourseFees", txtEcourseFees.Text.Trim());
                command.Parameters.AddWithValue("@CourseMarksMendartery", txtEMandetoryMarks.Text.Trim());
                command.Parameters.AddWithValue("@CourseYear", txtEyear.Value);
                command.Parameters.AddWithValue("@CourseDes", txtEcoursedes.Text.Trim());
                command.Parameters.AddWithValue("@CourseScope", txtEcourseScope.Text.Trim());
                command.Parameters.AddWithValue("@CareerForJobsAfterCourse", txtEjobs.Text.Trim());
                command.Parameters.AddWithValue("@CourseID", aid);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        Response.Write("<script>alert('add success...')</script>");
                        Response.Redirect("AdminCourse.aspx");
                    }
                }
                catch (Exception ex)
                {
                    // Handle exception
                }
            }
        }



    }
}