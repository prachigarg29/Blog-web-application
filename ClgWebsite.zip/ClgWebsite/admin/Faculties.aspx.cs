﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class admin_Faculties : System.Web.UI.Page
{
    long aid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlshowdata.Visible = true;
        pnladd.Visible = false;
        pnledt.Visible = false;
        if (Request.QueryString.HasKeys())
        {
            if (Request.QueryString["v"].ToString() == "EP")
            {
                pnledt.Visible = true;
                pnlshowdata.Visible = false;
                pnladd.Visible = false;
                aid = Convert.ToInt64(Request.QueryString["i"].ToString());
                getdata();
            }
            else if (Request.QueryString["v"].ToString() == "AP")
            {
                pnladd.Visible = true;
                pnledt.Visible = false;
                pnlshowdata.Visible = false;
            }
        }
        bindata();
    }
    public void bindata()
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select * from [ClgDB].[dbo].[tbl_faculties] ";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
    public void getdata()
    {
        if (!IsPostBack)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"select * from [ClgDB].[dbo].[tbl_faculties] where [facultyId]= " + aid;
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtEname.Text = ds.Tables[0].Rows[0]["facultyName"].ToString();
                txtEstatus.Value = ds.Tables[0].Rows[0]["status"].ToString();
                txtEdesignation.Text = ds.Tables[0].Rows[0]["Designation"].ToString();
                txtEUG.Text = ds.Tables[0].Rows[0]["UnderGraduate"].ToString();
                txtEpg.Text = ds.Tables[0].Rows[0]["PostGraduate"].ToString();
                txtEdepartment.Value = ds.Tables[0].Rows[0]["Department"].ToString();
                txtEphnno.Text = ds.Tables[0].Rows[0]["ContactNo"].ToString();
                txtEemail.Text = ds.Tables[0].Rows[0]["Email"].ToString();
                txtEsummary.Text = ds.Tables[0].Rows[0]["Summary"].ToString();

                txtEapproval.Value = ds.Tables[0].Rows[0]["approvalType"].ToString();
            }
        }
    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            string strPath = "";
            if (Facultyimg.HasFile)
            {
                strPath = "..\\img\\" + Facultyimg.FileName;
                string actPath = Server.MapPath(strPath);
                Facultyimg.SaveAs(actPath);
            }

            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"INSERT INTO [dbo].[tbl_faculties]
           ([facultyName]
           ,[Designation]
           ,[UnderGraduate]
           ,[PostGraduate]
           ,[Department]
           ,[ContactNo]
           ,[Email]
           ,[Summary]
           ,[FacultyImage]
           ,[status]
           ,[approvalType])
     VALUES('" + txtFname.Text.Trim() + "','" + txtdesignation.Text.Trim() + "','" + txtUG.Text.Trim() + "','" + txtpg.Text.Trim() + "','" + txtdepartment.Value + "','" + txtphnno.Text.Trim() + "','" + txtemail.Text.Trim() + "','" + txtsummary.Text.Trim() + "','" + strPath + "','" + txtstatus.Value + "','" + txtapprovaltype.Value + "')";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('add faculty...')</script>");
                txtemail.Text = string.Empty;
                txtFname.Text = string.Empty;
                txtUG.Text = string.Empty;
                txtpg.Text = string.Empty;
                txtphnno.Text = string.Empty;
                txtsummary.Text = string.Empty;
                txtdesignation.Text = string.Empty;
                bindata();
                Response.Redirect("Faculties.aspx");

            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }

    //protected void btnadd_Click(object sender, EventArgs e)
    //{
    //    pnladd.Visible = true;
    //    pnlshowdata.Visible = false;
    //}

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            if (e.CommandName == "DEL")
            {
                string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(strcon);
                string strcmd = @"delete from [ClgDB].[dbo].[tbl_faculties] where [facultyId]=" + Convert.ToInt64(e.CommandArgument);
                SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
                sqlcon.Open();
                if (sqlcmd.ExecuteNonQuery() > 0)
                {
                    //Response.Write("<script>alert('deleted successfully ...')</script>");
                    pnlshowdata.Visible = true;
                    pnladd.Visible = false;
                    pnledt.Visible = false;
                    bindata();
                    Response.Redirect("Faculties.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }

    protected void BtnUPDATE_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"update [ClgDB].[dbo].[tbl_faculties] set [facultyName]='" + txtEname.Text.Trim() + "', [Designation]='" + txtEdesignation.Text.Trim() + "',[UnderGraduate]='" + txtEUG.Text.Trim() + "',[PostGraduate]='" + txtEpg.Text.Trim() + "',[Department]='" + txtEdepartment.Value + "',[ContactNo]='" + txtEphnno.Text.Trim() + "',[Email]='" + txtEemail.Text.Trim() + "',[Summary]='" + txtEsummary.Text.Trim() + "',[status]='" + txtEstatus.Value + "',[approvalType]='" + txtEapproval.Value + "' where [facultyId]=" + aid;
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('updated successfully ...')</script>");
                pnlshowdata.Visible = true;
                pnladd.Visible = false;
                pnledt.Visible = false;
                bindata();
                Response.Redirect("Faculties.aspx");
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }

    }
}