﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class admin_StuAdmissionForm : System.Web.UI.Page
{
    long id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlViewDeatils.Visible = false;
        pnlshow.Visible = true;
        if (Request.QueryString.HasKeys())
        {
            id = Convert.ToInt64(Request.QueryString["sid"].ToString());
            pnlViewDeatils.Visible = true;
            pnlshow.Visible = false;
        }

        SqlConnection sqlcon = new SqlConnection("Data Source = PRACHI\\PRACHMSSQLSERVER; Initial Catalog = ClgDB; Integrated Security = True");
        string cmd = @"select *  FROM [ClgDB].[dbo].[tblAdmissionForm] where [AdmissionId] =" + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);

        DataSet ds = new DataSet();
        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            string name = ds.Tables[0].Rows[0]["ApplicantName"].ToString();
            Session.Add("name", name);
            dtlist.DataSource = ds;
            dtlist.DataBind();

        }

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            if (e.CommandName == "DEL")
            {
                SqlConnection sqlcon = new SqlConnection("Data Source = PRACHI\\PRACHMSSQLSERVER; Initial Catalog = ClgDB; Integrated Security = True");
                string cmd = @"delete  FROM [ClgDB].[dbo].[tblAdmissionForm] where [AdmissionId] =" + Convert.ToInt64(e.CommandArgument);
                SqlCommand sqlcmd = new SqlCommand(cmd, sqlcon);
                sqlcon.Open();
                if (sqlcmd.ExecuteNonQuery() > 0)
                {

                    Response.Redirect("StuAdmissionForm.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}