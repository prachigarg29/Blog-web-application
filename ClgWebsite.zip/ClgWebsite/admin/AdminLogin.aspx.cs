﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class admin_AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {

        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"SELECT  * FROM [ClgDB].[dbo].[tblAdminLogin] where AdminEmail='" + txtemail.Text.Trim() + "' and AdminPswd='" + txtpswd.Text.Trim() + "'";
        SqlDataAdapter sqlcmd = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlcmd.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session.Add("id",ds.Tables[0].Rows[0]["AdminID"].ToString());
            Response.Redirect("welcome.aspx");
        }
    }
}