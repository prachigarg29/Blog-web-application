﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class admin_members : System.Web.UI.Page
{
    long id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlShowMember.Visible = true;
        pnlAddMember.Visible = false;
        //pnlback.Visible = false;
        pnledit.Visible = false;
        
        {
            if (Request.QueryString.HasKeys())
            {
                if (Request.QueryString["v"].ToString() == "AM")
                {
                    pnlAddMember.Visible = true;
                    pnlShowMember.Visible = false;
                    pnledit.Visible = false;
                    //pnlback.Visible = true;
                  
                }
                else if (Request.QueryString["v"].ToString() == "EM")
                {
                    pnledit.Visible = true;
                    pnlAddMember.Visible = false;
                    pnlShowMember.Visible = false;
                    //pnlback.Visible = true;
                    id = Convert.ToInt64(Request.QueryString["Aid"].ToString());
                    fetchdata();
                }
            }
        }
        
    }
    public void fetchdata()
    {
        if (!IsPostBack)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"SELECT  [AdminID]
                              ,[ScreenName]
                              ,[fristName]
                              ,[LastName]
                              ,[AdminEmail]
                              ,[Status]
                              ,[UserType]
                              ,[AdminPswd]
                            FROM [ClgDB].[dbo].[tblAdminLogin] where AdminID =" + id;
            SqlDataAdapter sqlcmd = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlcmd.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                //long Aid = Convert.ToInt64(ds.Tables[0].Rows[0]["AdminID"].ToString());
                txtEFname.Text = ds.Tables[0].Rows[0]["fristName"].ToString();
                txtEscreenName.Text = ds.Tables[0].Rows[0]["ScreenName"].ToString();
                txtELName.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
                txtEemail.Text = ds.Tables[0].Rows[0]["AdminEmail"].ToString();
                txtEusertype.Value = ds.Tables[0].Rows[0]["AdminPswd"].ToString();
                txtEstatus.Value = ds.Tables[0].Rows[0]["Status"].ToString();
            }
        }
    }

    
    protected void BackBtn_Click(object sender, EventArgs e)
    {
        if (Request.UrlReferrer != null)
        {
            // Redirect to the previous page
            Response.Redirect(Request.UrlReferrer.ToString());
        }
        else
        {
            // If there is no previous page, you can redirect to a default page
            Response.Redirect("~/Default.aspx");
        }
    }

    protected void btnSaveChng_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"update [ClgDB].[dbo].[tblAdminLogin] set [ScreenName]='" + txtEscreenName.Text.Trim() + "', [fristName]='" + txtEFname.Text.Trim() + "' , [LastName]='" + txtELName.Text.Trim() + "', [AdminEmail]='" + txtEemail.Text.Trim() + "',[Status]='" + txtstatus.SelectedItem.Text + "',[UserType]='" + txtEusertype.Value + "' where AdminID=" + id;
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('updated success...')</script>");
                Response.Redirect("members.aspx");
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }

    protected void btnaddMem_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"insert into [ClgDB].[dbo].[tblAdminLogin] ([ScreenName]
                      ,[fristName]
                      ,[LastName]
                      ,[AdminEmail]
                      ,[Status]
                      ,[UserType]
                      ,[AdminPswd]) values ('" + txtscreenName.Text.Trim() + "','" + txtFname.Text.Trim() + "','" + txtLname.Text.Trim() + "','" + txtemail.Text.Trim() + "','" + txtstatus.SelectedItem.Text + "','" + txtunsertype.Value + "','" + txtpswd.Text.Trim() + "')";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('added member success...')</script>");
                Response.Redirect("members.aspx");
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            if (e.CommandName == "DEL")
            {
                string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(strcon);
                string strcmd = @"delete from [ClgDB].[dbo].[tblAdminLogin]  where AdminID=" + Convert.ToInt64(e.CommandArgument);
                SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
                sqlcon.Open();
                if (sqlcmd.ExecuteNonQuery() > 0)
                {
                    Response.Write("<script>alert('deleted member success...')</script>");
                    Response.Redirect("members.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}