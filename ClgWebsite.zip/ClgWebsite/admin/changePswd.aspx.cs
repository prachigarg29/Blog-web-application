﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class admin_addmember : System.Web.UI.Page
{
    string strcon = "";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {
            strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"select [AdminPswd] FROM [ClgDB].[dbo].[tblAdminLogin] where [AdminID]=" + id;
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                string oldpswd = ds.Tables[0].Rows[0]["AdminPswd"].ToString();
                if (oldpswd == txtoldpswd.Text)
                {
                    SqlConnection sqlconn = new SqlConnection(strcon);
                    string updPswd = @"update [ClgDB].[dbo].[tblAdminLogin] set [AdminPswd]='" + txtpswd.Text.Trim() + "' where [AdminID]=" + id;
                    SqlCommand sqlcmd = new SqlCommand(updPswd, sqlconn);
                    sqlconn.Open();
                    if (sqlcmd.ExecuteNonQuery() > 0)
                    {
                        Response.Write("<script>alert('Password Changed ')</script>");
                        txtConNewpswd.Text = string.Empty;
                        txtpswd.Text = string.Empty;
                        txtConNewpswd.Text = string.Empty;
                    }
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}