﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin_StuContactDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {

            if (e.CommandName == "DEL")
            {
                SqlConnection sqlcon = new SqlConnection("Data Source = PRACHI\\PRACHMSSQLSERVER; Initial Catalog = ClgDB; Integrated Security = True");
                string cmd = @"delete  FROM [ClgDB].[dbo].[tblStuContact] where  [StuId] =" + Convert.ToInt64(e.CommandArgument);
                SqlCommand sqlcmd = new SqlCommand(cmd, sqlcon);
                sqlcon.Open();
                if (sqlcmd.ExecuteNonQuery() > 0)
                {

                    Response.Redirect("StuContactDetail.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}