﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class admin_aboutSec : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        getdata();
    }
    public void getdata()
    {
        if (!IsPostBack)
        {
            long id = Convert.ToInt64(Session["id"]);
            if (id > 0)
            {
                string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(strcon);
                string strcmd = @"select [aboutDes]  FROM [ClgDB].[dbo].[staticData]";
                SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
                DataSet ds = new DataSet();
                sqlad.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtabout.Text = ds.Tables[0].Rows[0]["aboutDes"].ToString();

                }
            }
            else
            {
                Response.Redirect("AdminLogin.aspx");
            }
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"update [ClgDB].[dbo].[staticData] set aboutDes='" + txtabout.Text.Trim() + "'";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('updated successfully ...')</script>");
            }
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}