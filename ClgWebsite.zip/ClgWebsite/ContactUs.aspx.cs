﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void btnsave_Click(object sender, EventArgs e)
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        long id = Convert.ToInt64(Session["id"]);
        string strcmd = @"insert into  [ClgDB].[dbo].[tblStuContact] ([StuName],[StuAdress],[StuNumber],[StuMsg]) values ('"+txtname.Text.Trim()+"','"+txtadress.Text.Trim()+"','"+txtmobile.Text.Trim()+"','"+txtmsg.Text.Trim()+"')";
        SqlCommand sqlcmd = new SqlCommand(strcmd,sqlcon);
        sqlcon.Open();
        if(sqlcmd.ExecuteNonQuery()>0)
        {
            Response.Write("<script>alert('Message Sent...')</script>");
            txtname.Text = string.Empty;
            txtadress.Text = string.Empty;
            txtmobile.Text = string.Empty;
            txtmsg.Text = string.Empty;
        }
    }
}