﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsubmut_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["id"]);
        if (id > 0)
        {
            string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"INSERT INTO [dbo].[tblAdmissionForm]
           ([CourseApplied]
           ,[ApplicantName]
           ,[FatherName]
           ,[MotherName]
           ,[DOB]
           ,[MobileNo]
           ,[Gender]
           ,[Religion]
           ,[BloodGrp]
           ,[Nationality]
           ,[AdharNo]
           ,[Email]
           ,[adress]
           ,[board10th]
           ,[marks10th]
           ,[Subject10th]
           ,[School10th]
           ,[PassingYear10th]
           ,[Board12th]
           ,[Marks12th]
           ,[Subject12th]
           ,[School12th]
           ,[PassingYear12th]
           ,[StreamInGra]
           ,[GraSubject]
           ,[GraBoard]
           ,[GraCollege]
           ,[GraMarks]
           ,[CourseDuration])
     VALUES ('" + txtcourse.Value + "','" + txtname.Text.Trim() + "','" + txtfathername.Text.Trim() + "','" + txtmothername.Text.Trim() + "','" + txtdob.Text.Trim() + "','" + txtphnno.Text.Trim() + "','" + txtgender.Value + "','" + txtreligion.Value + "','" + txtblood_group.Value + "','" + txtnationality.Value + "','" + txtadharno.Text.Trim() + "','" + txtemail.Text.Trim() + "','" + txtadress.Text.Trim() + "','" + txtboard.Text.Trim() + "','" + txtmarks.Text.Trim() + "','" + txtsubject.Text.Trim() + "','" + txtschool.Text.Trim() + "','" + txtpassyear.Value + "','" + txt12board.Text.Trim() + "','" + txt12marks.Text.Trim() + "','" + txtsubject.Text.Trim() + "','" + txt12school.Text.Trim() + "','" + txt12Year.Value + "','" + txtstream.Value + "','" + txtgradutionSub.Text.Trim() + "','" + txtgraduationBoard.Text.Trim() + "','" + txtgradutionSchool.Text.Trim() + "','" + txtgraduationMarks.Text.Trim() + "','" + txtgrad_duration.Value + "')";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Form Filled...')</script>");
                Response.Redirect("HomePage.aspx");
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }
}