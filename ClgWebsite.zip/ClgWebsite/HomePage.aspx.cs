﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class HomePage : System.Web.UI.Page
{
    long id = 0;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlhome.Visible = true;
        pnlReadMore.Visible = false;
        if(Request.QueryString.HasKeys())
        {
            id = Convert.ToInt64(Request.QueryString["id"].ToString());
            pnlReadMore.Visible = true;
            pnlhome.Visible = false;
            bindCourse();
        }

        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select * from [ClgDB].[dbo].[tblcourse]";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dtlist.DataSource = ds;
            dtlist.DataBind();

        }
    }
    public void bindCourse()
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select * from [ClgDB].[dbo].[tblcourse] where [CourseID]="+id;
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DataList1.DataSource = ds;
            DataList1.DataBind();

        }
    }
}