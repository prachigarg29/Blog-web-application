﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnregister_Click(object sender, EventArgs e)
    {
        string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=ClgDB;Integrated Security=True";
        SqlConnection sqlcon = new SqlConnection(strcon);
        string str = @"insert into [ClgDB].[dbo].[StuTbl] ([StuName]
      ,[StuRollNo]
      ,[StuFatherName]
      ,[StuEmail]
      ,[StuPswd]) values ('"+txtName.Text.Trim()+"','"+txtrollno.Text.Trim()+"','"+txtfatherN.Text.Trim()+"','"+txtemail.Text.Trim()+"','"+txtpswd.Text.Trim()+"')";
        SqlCommand cmd = new SqlCommand(str,sqlcon);
        sqlcon.Open();
        if (cmd.ExecuteNonQuery() > 0)
        {
            txtName.Text=string.Empty;
            txtfatherN.Text = string.Empty;
            txtpswd.Text = string.Empty;
            txtemail.Text = string.Empty;
            txtrollno.Text = string.Empty;
            Response.Redirect("login.aspx");
        }
    }
}