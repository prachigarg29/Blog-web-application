﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class signup : System.Web.UI.Page
{
    string connectionStr = "Data Source=PRACHI\\PRACHMSSQLSERVER;Initial Catalog=dp_user;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
       // string strcon = ConfigurationManager.ConnectionStrings[""].ToString();
        SqlConnection sqlcon = new SqlConnection(connectionStr);

        string strcmd = @"INSERT INTO [dbo].[tbl_blog_data] ([First_Name],[Last_Name],[Email],[Password]) VALUES('"+txtFirstName.Text.Trim()+"','"+txtLastName.Text.Trim()+"','"+txtEmail.Text.Trim()+"','"+txtPassword.Text.Trim()+"')";

        SqlCommand sqlcmd = new SqlCommand(strcmd,sqlcon);
        sqlcon.Open();
        int i = sqlcmd.ExecuteNonQuery();
        if (i > 0)
        {
            Response.Write("<script>alert('inserted')</script>");
            Response.Redirect("login.aspx");
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtRepeatPassword.Text = string.Empty;
        }
    }
}