﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class webAdmin_showusercmmt : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        //string strcon = @"Data Source=PRACHI\PMSSQLSERVER;Initial Catalog=myBlog;Integrated Security=True";
        bindata();   
        
        
    }
    public void bindata()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        string strcmd = @"SELECT * FROM [dbo].[tbl_Users]";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {

            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DEL")
        {
            SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
            sqlcon.Open();

            SqlTransaction transaction = sqlcon.BeginTransaction();

            try
            {
                long userId = Convert.ToInt64(e.CommandArgument);
                string str_user = @"DELETE FROM [dbo].[tbl_Users] WHERE [userID] = " + Convert.ToInt64(e.CommandArgument);
                // Delete from tbl_Users
                using (SqlCommand cmdUsers = new SqlCommand(str_user, sqlcon, transaction))
                {
                    cmdUsers.Parameters.AddWithValue("@UserId", userId);
                    cmdUsers.ExecuteNonQuery();
                }
                string str_post=@"DELETE FROM [myBlog].[dbo].[tbl_posts] WHERE [Post_Creator]=" + Convert.ToInt64(e.CommandArgument);
                // Delete from tbl_posts
                using (SqlCommand cmdPosts = new SqlCommand(str_post, sqlcon, transaction))
                {
                    cmdPosts.Parameters.AddWithValue("@UserId", userId);
                    cmdPosts.ExecuteNonQuery();
                }
                string str_cmmt = @"DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [Comment_creator]=" + Convert.ToInt64(e.CommandArgument);
                // Delete from tbl_cmmt
                using (SqlCommand cmdComments = new SqlCommand(str_cmmt, sqlcon, transaction))
                {
                    cmdComments.Parameters.AddWithValue("@UserId", userId);
                    cmdComments.ExecuteNonQuery();
                }
                string str_cmmt_like = @"DELETE FROM [myBlog].[dbo].[tbl_cmmt_like] WHERE [user_id]=" + Convert.ToInt64(e.CommandArgument);
                // Delete from tbl_cmmt_like
                using (SqlCommand cmdCommentLikes = new SqlCommand(str_cmmt_like, sqlcon, transaction))
                {
                    cmdCommentLikes.Parameters.AddWithValue("@UserId", userId);
                    cmdCommentLikes.ExecuteNonQuery();
                }
                string str_like="DELETE FROM [myBlog].[dbo].[tbl_like_dislike] WHERE [user_id] ="+Convert.ToInt64(e.CommandArgument);
                // Delete from tbl_like_dislike
                using (SqlCommand cmdLikeDislike = new SqlCommand(str_like, sqlcon, transaction))
                {
                    cmdLikeDislike.Parameters.AddWithValue("@UserId", userId);
                    cmdLikeDislike.ExecuteNonQuery();
                }

                // Commit the transaction if all queries succeed
                transaction.Commit();

                Response.Write("<script>alert('DELETE RECORD')</script>" + Convert.ToInt64(e.CommandArgument));
                bindata();
            }
            catch (Exception ex)
            {
                // Handle exceptions and roll back the transaction on failure
                transaction.Rollback();
                // Log or handle the exception as needed
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }

}