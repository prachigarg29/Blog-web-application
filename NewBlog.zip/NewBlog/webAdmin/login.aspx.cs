﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class login : System.Web.UI.Page
{
    string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=dp_user;Integrated Security=True";
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(strcon);

        string strcmd = @"SELECT [Email] , [Password] FROM [dbo].[tbl_blog_data] where Email='" + txtEmail.Text.Trim() + "' and password='" + txtPassword.Text.Trim() + "' ";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd,sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Response.Redirect("welcome.aspx");
            txtEmail.Text = string.Empty;
            txtPassword.Text = string.Empty;
        }
        else
        {
            Response.Write("<script>alert('Login Failed.... ')</script>");
        }
    }
}