﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class webAdmin_showAllCategories : System.Web.UI.Page
{
   
    long ud = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.HasKeys())
        {
            pnledit.Visible = true;
            pnl_show.Visible = false;
            ud = Convert.ToInt64(Request.QueryString["i"].ToString());
            getdata();
        }
        else
        {
            pnledit.Visible = false;
            
        }
        bindata();
    }
    public void getdata()
    {
        if(!IsPostBack)
        {
            SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);

        string strcmd = @"SELECT * FROM [dbo].[tbl_Category] where [catID] ="+ud;

        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);

        DataSet ds = new DataSet();

        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            txt_category.Text=ds.Tables[0].Rows[0]["catName"].ToString();
        }
        }
    }

    public void bindata()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);

        string strcmd = @"SELECT * FROM [dbo].[tbl_Category] ";

        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);

        DataSet ds = new DataSet();

        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DEL")
        {
            SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
            sqlcon.Open();

            SqlTransaction transaction = sqlcon.BeginTransaction();

            try
            {
                long catId = Convert.ToInt64(e.CommandArgument);

                // Delete from tbl_Category
                using (SqlCommand cmdCategory = new SqlCommand("DELETE FROM [dbo].[tbl_Category] WHERE [catID] = @CatId", sqlcon, transaction))
                {
                    cmdCategory.Parameters.AddWithValue("@CatId", catId);
                    cmdCategory.ExecuteNonQuery();
                }

                // Delete from tbl_posts
                using (SqlCommand cmdPosts = new SqlCommand("DELETE FROM [myBlog].[dbo].[tbl_posts] WHERE [Post_Category] = @CatId", sqlcon, transaction))
                {
                    cmdPosts.Parameters.AddWithValue("@CatId", catId);
                    cmdPosts.ExecuteNonQuery();
                }
                string strcmd =@"DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] IN (SELECT [Blog_id] FROM [myBlog].[dbo].[tbl_posts] WHERE [Post_Category] = "+catId+")";
                // Delete from tbl_cmmt
                using (SqlCommand cmdComments = new SqlCommand(strcmd, sqlcon, transaction))
                {
                  //  cmdComments.Parameters.AddWithValue("@CatId", catId);
                    cmdComments.ExecuteNonQuery();
                }
                string strlike=@"DELETE FROM [myBlog].[dbo].[tbl_cmmt_like] WHERE [blog_id] IN (SELECT [Blog_id] FROM [myBlog].[dbo].[tbl_posts] WHERE [Post_Category] = "+catId+")";
                // Delete from tbl_cmmt_like
                using (SqlCommand cmdCommentLikes = new SqlCommand(strlike, sqlcon, transaction))
                {
                   // cmdCommentLikes.Parameters.AddWithValue("@CatId", catId);
                    cmdCommentLikes.ExecuteNonQuery();
                }
                string str_dis_like =@"DELETE FROM [myBlog].[dbo].[tbl_like_dislike] WHERE [Blog_id] IN (SELECT [Blog_id] FROM [myBlog].[dbo].[tbl_posts] WHERE [Post_Category] ="+catId+")";
                // Delete from tbl_like_dislike
                using (SqlCommand cmdLikeDislike = new SqlCommand(str_dis_like, sqlcon, transaction))
                {
                   // cmdLikeDislike.Parameters.AddWithValue("@CatId", catId);
                    cmdLikeDislike.ExecuteNonQuery();
                }

                // Commit the transaction if all queries succeed
                transaction.Commit();

                Response.Write("<script>alert('DELETE RECORD')</script>" + Convert.ToInt64(e.CommandArgument));
                bindata();
            }
            catch (Exception ex)
            {
                // Handle exceptions and roll back the transaction on failure
                transaction.Rollback();
                // Log or handle the exception as needed
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }

    protected void Btn_newcat_Click(object sender, EventArgs e)
    {
        if (ud > 0)
        {
            updatecat();
            bindata();
        }
    }
    public void updatecat()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);

        string strcmd = @"UPDATE [dbo].[tbl_Category] set [catName] ='"+txt_category.Text.Trim()+"' where [catID]="+ud;

        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        
        sqlcon.Open();
        
        int i = sqlcmd.ExecuteNonQuery();

        if (i > 0)
        {
            Response.Write("<script>alert('Update Category !!!!!!....')</script>");
        }
    }
}