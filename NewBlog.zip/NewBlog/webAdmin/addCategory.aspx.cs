﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class webAdmin_manageCategories : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCreateCategory_Click(object sender, EventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);

        string strcmd = @"INSERT INTO [dbo].[tbl_Category] ([catName]) VALUES('"+txtCat.Text.Trim()+"')";
        SqlCommand sqlcmd = new SqlCommand(strcmd,sqlcon);
        sqlcon.Open();
        int i = sqlcmd.ExecuteNonQuery();
        if (i > 0)
        {
            Response.Write("<script>alert('adding new category is done..... ')</script>");
            txtCat.Text = string.Empty;
            
            Response.Redirect("showAllCategories.aspx");
        }
        else
        {
            Response.Write("<script>alert('Not add...')</script>");
        }
    }
}