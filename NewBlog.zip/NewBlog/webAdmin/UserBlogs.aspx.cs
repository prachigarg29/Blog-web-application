﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class webAdmin_UserBlogs : System.Web.UI.Page
{
    long blogid = 0;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
            string strcmd = @"SELECT tbl_posts.Blog_id,
                            tbl_posts.Post_title,
                            (case when len (tbl_posts.Post_description)>150 THEN SUBSTRING(tbl_posts.Post_description,1,150)+'....' ELSE tbl_posts.Post_description END) as Post_description,
                            tbl_posts.Post_Creator,
                            tbl_posts.Post_Category,
                            tbl_posts.Post_images,
                            tbl_posts.Created_date,
                            tbl_posts.is_locked, 
                            tbl_posts.is_deleted, 
                            tbl_Category.catName,
                            COUNT(CASE WHEN tbl_like_dislike.isLike = 1 THEN 1 END) as is_like,
                            COUNT(CASE WHEN tbl_like_dislike.isLike = 0 THEN 1 END) as is_dislike
                             FROM tbl_posts 
                            LEFT JOIN 
                            tbl_like_dislike ON tbl_like_dislike.Blog_id = tbl_posts.Blog_id 
                            LEFT JOIN 
                            tbl_Category ON tbl_Category.catID = tbl_posts.Post_Category 
                            GROUP BY 
                            tbl_posts.Blog_id,
                            tbl_posts.Post_title, 
                            tbl_posts.Post_description, 
                            tbl_posts.Post_Creator, 
                            tbl_posts.Post_Category,
                            tbl_posts.Post_images, 
                            tbl_posts.Created_date, 
                            tbl_posts.is_locked,
                            tbl_posts.is_deleted,    
                            tbl_Category.catName";


            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
        }
    }

   

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
            if (e.CommandName == "del")
            {
                int postID = Convert.ToInt32(e.CommandArgument);
               
                SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
                sqlcon.Open();
                SqlTransaction transaction = sqlcon.BeginTransaction();

                try
                {
                    // 1. Delete comments related to the post
                    string deleteCommentsQuery = @"DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = " + postID;
                    using (SqlCommand deleteCommentsCmd = new SqlCommand(deleteCommentsQuery, sqlcon, transaction))
                    {
                        deleteCommentsCmd.ExecuteNonQuery();
                    }

                    // 2. Delete likes/dislikes related to the post
                    string deleteLikesDislikesQuery = @"DELETE FROM [myBlog].[dbo].[tbl_like_dislike] WHERE [Blog_id] = " + postID;
                    using (SqlCommand deleteLikesDislikesCmd = new SqlCommand(deleteLikesDislikesQuery, sqlcon, transaction))
                    {
                        deleteLikesDislikesCmd.ExecuteNonQuery();
                    }

                    // 3. Delete the post
                    string deletePostQuery = @"DELETE FROM [myBlog].[dbo].[tbl_posts] WHERE [Blog_id] = " + postID;
                    using (SqlCommand deletePostCmd = new SqlCommand(deletePostQuery, sqlcon, transaction))
                    {
                        deletePostCmd.ExecuteNonQuery();
                    }

                    // If everything is successful, commit the transaction
                    transaction.Commit();
                    Response.Redirect("UserBlogs.aspx");
                }
                catch (Exception ex)
                {
                    // An error occurred, rollback the transaction
                    transaction.Rollback();
                    // Handle the exception or log it
                }
                
            }
            else if (e.CommandName == "lck")
            {
                blogid = Convert.ToInt32(e.CommandArgument);
                SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
                string strcmd = @"SELECT [is_locked] FROM [myBlog].[dbo].[tbl_posts] WHERE Blog_id=" + blogid;
                SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
                sqlcon.Open();
                object result = sqlcmd.ExecuteScalar();

                if (result != null)
                {
                    int i = Convert.ToInt32(result);

                    if (i == 0)
                    {
                        string str_insert = @"UPDATE [myBlog].[dbo].[tbl_posts] SET [is_locked]=" + 1 + " WHERE Blog_id =" + blogid;
                        SqlCommand sql_insert_cmd = new SqlCommand(str_insert, sqlcon);
                        int exe_query = sql_insert_cmd.ExecuteNonQuery();

                        if (exe_query > 0)
                        {
                            Response.Redirect("UserBlogs.aspx");
                        }
                    }
                    else if (i > 0)
                    {
                        string str_updte = @"UPDATE [myBlog].[dbo].[tbl_posts] SET [is_locked]=" + 0 + " WHERE Blog_id =" + blogid;
                        SqlCommand sql_updte_cmd = new SqlCommand(str_updte, sqlcon);
                        int exe_query = sql_updte_cmd.ExecuteNonQuery();

                        if (exe_query > 0)
                        {
                            Response.Redirect("UserBlogs.aspx");
                        }
                    }
                }
                
            }

        }




    protected void lckpost_Click(object sender, ImageClickEventArgs e)
    {

    }
}