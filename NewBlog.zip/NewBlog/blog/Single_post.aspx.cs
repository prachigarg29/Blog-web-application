﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class blog_Single_post : System.Web.UI.Page
{
    long blogid = 0;
    string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=myBlog;Integrated Security=True";
    string postid = "";
    long uID = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString.HasKeys())
            {
                if (long.TryParse(Request.QueryString["post_id"], out blogid))
                {
                    SqlConnection sqlcon = new SqlConnection(strcon);
                    string strcmd = @"SELECT [Blog_id],[Post_title],[Post_description],[Created_date],[Post_Category],[Post_Creator],[Post_images],[is_like],[is_dislike] FROM [myBlog].[dbo].[tbl_posts] where Blog_id=" + blogid;
                    SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
                    DataSet ds = new DataSet();
                    sqlad.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        ddl_show_details.DataSource = ds;
                        ddl_show_details.DataBind();
                    }
                    fetchdata();
                    likeCount();
                    dislikeCount();
                    checkLikeDislike();
                    latest_post();
                    user_details();
                }
            }
        }
        bool isLocked = IsCommentPanelVisible();
        if (isLocked == true || Convert.ToInt64(Session["userID"])==0)
        {
            commentFormPanel.Visible = false;
        }
        else
        {
            commentFormPanel.Visible = true;
        }

        GetPreviousPostTitle();
        GetNextPostTitle();

        // fetchlike();
    }

    public void user_details()
    {
        string postid = Request.QueryString["post_id"].ToString();
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"select usr.userPicPath,usr.firstName ,usr.[userID], usr.lastName from tbl_Users usr INNER JOIN tbl_posts pst ON pst.Post_Creator=usr.userID where Blog_id=" + postid;
        SqlDataAdapter sqlcmd = new SqlDataAdapter(strcmd,sqlcon);
        DataSet ds = new DataSet();
        sqlcmd.Fill(ds);
        if (ds.Tables[0].Rows.Count>0)
        {
            User_datalist.DataSource = ds;
            User_datalist.DataBind();
        }
    }
    public void latest_post()
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"SELECT TOP 3 * FROM [myBlog].[dbo].[tbl_posts]
                     ORDER BY [Blog_id] DESC";

        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();

        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            // Set DataList's DataSource to the DataSet
            dtalist_latest_post.DataSource = ds.Tables[0];
            dtalist_latest_post.DataBind();
        }
    }
    public void GetPreviousPostTitle()
    {
        if (long.TryParse(Request.QueryString["post_id"], out blogid))
        {
            SqlConnection sqlcon = new SqlConnection(strcon);
            string query = @"SELECT TOP 1 [Post_Title],Blog_id FROM [myBlog].[dbo].[tbl_posts] 
                         WHERE [Blog_id] > " + blogid + " ORDER BY [Blog_id] DESC";
            SqlDataAdapter sqlad = new SqlDataAdapter(query, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                // Set DataList's DataSource to the DataSet
                dtalist_pre_post.DataSource = ds.Tables[0];
                dtalist_pre_post.DataBind();
            }
        }
    }
    public void GetNextPostTitle()
    {
        if (long.TryParse(Request.QueryString["post_id"], out blogid))
        {
            SqlConnection sqlcon = new SqlConnection(strcon);
            string query = @"SELECT TOP 1 [Post_Title],[Blog_id] FROM [myBlog].[dbo].[tbl_posts] 
                         WHERE [Blog_id] < " + blogid + " ORDER BY [Blog_id] DESC";
            SqlDataAdapter sqlad = new SqlDataAdapter(query, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dtalist_next_post.DataSource = ds.Tables[0];
                dtalist_next_post.DataBind();
            }
        }
    }

    public bool IsCommentPanelVisible()
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"SELECT [is_locked] FROM [myBlog].[dbo].[tbl_posts] WHERE Blog_id = " + blogid;
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        object result = sqlcmd.ExecuteScalar();
        if (result != null)
        {
            bool isLocked = Convert.ToBoolean(result);
            return isLocked;
        }
        else
        {
            return false;
        }
    }

    public void likeCount()
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
        blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
        string checkQuery = "select count(isLike) as likeCount from tbl_like_dislike where Blog_id=" + blogid + " and isLike=1";
        SqlDataAdapter adp = new SqlDataAdapter(checkQuery, sqlcon);
      
        DataSet ds = new DataSet();
        adp.Fill(ds);
        sqlcon.Open();
        string update_like_Query = "UPDATE [myBlog].[dbo].[tbl_posts] SET [is_like] = (SELECT COUNT(isLike) FROM tbl_like_dislike WHERE Blog_id = " + blogid + " AND isLike = 1) WHERE Blog_id = " + blogid;

        SqlCommand sqlcmd = new SqlCommand(update_like_Query, sqlcon);
        int i = sqlcmd.ExecuteNonQuery();

        if (ds.Tables[0].Rows.Count > 0)
        {
            Label1.Text = ds.Tables[0].Rows[0]["likeCount"].ToString();
        }

    }
    public void dislikeCount()
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
        blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
        string checkQuery = "select count(isLike) as dislikeCount from tbl_like_dislike where Blog_id=" + blogid + " and isLike=0";
        SqlDataAdapter adp = new SqlDataAdapter(checkQuery, sqlcon);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        sqlcon.Open();
        string update_dislike_Query = "UPDATE [myBlog].[dbo].[tbl_posts] SET [is_dislike] = (SELECT COUNT(isLike) FROM tbl_like_dislike WHERE Blog_id = " + blogid + " AND isLike = 0) WHERE Blog_id = " + blogid;
        SqlCommand sqlcmd = new SqlCommand(update_dislike_Query, sqlcon);
        int i = sqlcmd.ExecuteNonQuery();

        if (ds.Tables[0].Rows.Count > 0)
        {
            Label2.Text = ds.Tables[0].Rows[0]["dislikeCount"].ToString();
        }

    }

    protected void btn_submit_Click(object sender, EventArgs e)
    {
        // This method is called when the submit button is clicked
        SqlConnection sqlcon = new SqlConnection(strcon);
        blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
        long userID = Convert.ToInt32(Session["userID"]);
        if (userID>0)
        {
            string commentText = txt_cmmt.Text.Trim();

            // Insert the new comment into the database
            string strcmd = @"INSERT INTO [dbo].[tbl_cmmt] ([comment],[Comment_creator],[comment_Date],[post_id]) OUTPUT INSERTED.post_id VALUES('" + commentText + "'," + userID + ",GETDATE()," + blogid + ")";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);

            if (sqlcon.State != ConnectionState.Open)
            {
                sqlcon.Open();
            }

            try
            {
                int i = sqlcmd.ExecuteNonQuery();
                if (i > 0)
                {
                    // Comment inserted successfully, now UpdatePanel1 the comments and make the panel visible
                    fetchdata();
                    string postid = Request.QueryString["post_id"];
                    Response.Redirect("Single_post.aspx?post_id=" + postid);
                    txt_cmmt.Text = string.Empty;
                }

            }
            catch (Exception ex)
            {
                // Log the exception or display an error message
                Console.WriteLine("Exception during comment insertion: " + ex.Message);
            }
            finally
            {
                sqlcon.Close();
            }
        }
        else
        {
            Response.Write("<script>alert('Sorry.!! Firstly You have to LOGIN Your Accout.. ')</script>");
            Response.Redirect("../webUser/login.aspx");
        }
    }
    public void fetchdata()
    {
        string postid = Request.QueryString["post_id"].ToString();
        postid = postid.Replace("'", ""); // This will remove all occurrences of %27 in the string
        blogid = Convert.ToInt64(postid);
        long userid = Convert.ToInt64(Session["userid"]);
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @" SELECT cm.[comment_id],
                            cm.[comment],
                            cm.[Comment_creator],
                            cm.[comment_Date],
                            cm.[parent_id],
                            cm.[is_like], 
                            cm.[is_dislike],
                            cm.[is_deleted],
                            cm.[post_id],
                            usr.[userPicPath],
                            usr.[userID],
                            usr.[firstName],
                            usr.[lastName],
                            COALESCE(likecmt.[islike], 0) AS [comment_like]
                        FROM [dbo].[tbl_cmmt] cm
                        INNER JOIN tbl_Users usr ON cm.[Comment_creator] = usr.userID
                        LEFT JOIN [myBlog].[dbo].[tbl_cmmt_like] likecmt 
                            ON cm.[comment_id] = likecmt.[cmmt_id] 
                            AND likecmt.[user_id] =" + userid + " AND likecmt.[blog_id] = " + blogid + "  WHERE cm.[parent_id] = 0 AND cm.[post_id] =" + postid;
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();

        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            cmmtPnlShow.Visible = true;
            string cmmt_id = ds.Tables[0].Rows[0]["comment_id"].ToString();
            Session.Add("cmmt_id", cmmt_id);
            uID= Convert.ToInt64(ds.Tables[0].Rows[0]["userID"]);
            dtalist.DataSource = ds;
            dtalist.DataBind();
            
        }
        else
        {
            cmmtPnlShow.Visible = false;
        }
        
    }

    protected void btnDislike_Click(object sender, ImageClickEventArgs e)
    {
        DIslike();
        string postid = Request.QueryString["post_id"];
        Response.Redirect("Single_post.aspx?post_id=" + postid);

    }
    protected void btnLike_Click(object sender, ImageClickEventArgs e)
    {
        like();
        string postid = Request.QueryString["post_id"];
        Response.Redirect("Single_post.aspx?post_id=" + postid);

    }

    public void checkLikeDislike()
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
        string postid = Request.QueryString["post_id"].ToString();
        postid = postid.Replace("'", ""); // This will remove all occurrences of %27 in the string
        long blogid = Convert.ToInt64(postid);
        long userID = Convert.ToInt32(Session["userID"]);
        string checkQuery = "SELECT isLike FROM [myBlog].[dbo].[tbl_like_dislike] WHERE Blog_id = '" + blogid + "' AND user_id ='" + userID + "'";
        SqlDataAdapter checkCmd = new SqlDataAdapter(checkQuery, sqlcon);

        if (sqlcon.State != ConnectionState.Open)
        {
            sqlcon.Open();
        }

        DataSet ds = new DataSet();
        checkCmd.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            bool isLiked = Convert.ToBoolean(ds.Tables[0].Rows[0]["isLike"]);

            if (isLiked)
            {
                btnLike.ImageUrl = "../blog/images/like_blue.png";
                btnDislike.ImageUrl = "../blog/Images/dislike3.png";

            }
            else
            {
                btnDislike.ImageUrl = "../blog/images/dislike_blue.png";
                btnLike.ImageUrl = "../blog/images/like1.png";

            }
        }
        else
        {
            btnLike.ImageUrl = "../blog/images/like1.png";
            btnDislike.ImageUrl = "../blog/Images/dislike3.png";

        }
    }

    public void DIslike()
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
        string postid = Request.QueryString["post_id"].ToString();
        postid = postid.Replace("'", ""); // This will remove all occurrences of %27 in the string
        long blogid = Convert.ToInt64(postid);
        long userID = Convert.ToInt32(Session["userID"]);
        if(userID>0)
        {
            // Check if the user has already liked the post
            string checkQuery = "SELECT COUNT(*) FROM [myBlog].[dbo].[tbl_like_dislike] WHERE Blog_id = " + blogid + " AND user_id =" + userID + " ";
            SqlCommand checkCmd = new SqlCommand(checkQuery, sqlcon);
            if (sqlcon.State != ConnectionState.Open)
            {
                sqlcon.Open();
            }
            int existingLikes = (int)checkCmd.ExecuteScalar();

            btnDislike.ImageUrl = "../blog/images/dislike_blue.png";
            if (existingLikes > 0)
            {
                // The user has already liked the post, update the value of dislike to 0
                string updateQuery = "UPDATE [myBlog].[dbo].[tbl_like_dislike] SET [isLike] = 0 WHERE Blog_id =" + blogid + " AND user_id =" + userID + " ";
                SqlCommand updateCmd = new SqlCommand(updateQuery, sqlcon);
                int rowsAffected = updateCmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    //Label2.Text = "Dislike";
                }
            }
            else
            {
                // The user has not liked the post, insert a new record with dislike set to 0
                string insertQuery = "INSERT INTO [myBlog].[dbo].[tbl_like_dislike] (Blog_id, user_id, isLike) VALUES (" + blogid + ", " + userID + " , 0)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, sqlcon);
                int rowsAffected = insertCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('You are now disliking this post.')</script>");
                    string checkQuery1 = "SELECT COUNT(*) FROM [myBlog].[dbo].[tbl_like_dislike] WHERE Blog_id = " + blogid + " AND user_id = " + userID + " ";
                    SqlCommand checkCmd1 = new SqlCommand(checkQuery1, sqlcon);

                    int existingLikes1 = (int)checkCmd1.ExecuteScalar();
                    if (existingLikes1 > 0)
                    {
                        btnDislike.Enabled = false;
                    }
                }
            }
        }
        else
        {
            Response.Write("<script>alert('Sorry.!! Firstly You have to LOGIN Your Accout.. ')</script>");
            Response.Redirect("../webUser/login.aspx");
        }
        sqlcon.Close();
    }

    public void like()
    {
        string postid = Request.QueryString["post_id"];

        if (!string.IsNullOrEmpty(postid))
        {
            postid = postid.Replace("'", ""); // Remove any single quotes from the post_id
            long blogid = 0;
            if (long.TryParse(postid, out blogid))
            {
                if (Convert.ToInt64(Session["userID"]) >0)
                {
                    long userID = Convert.ToInt64(Session["userID"]);
                    SqlConnection sqlcon = new SqlConnection(strcon);
                    if (sqlcon.State != ConnectionState.Open)
                    {
                        sqlcon.Open();
                    }
                    // Check if the user has already liked the post
                    string checkQuery = "SELECT COUNT(*) FROM [myBlog].[dbo].[tbl_like_dislike] WHERE Blog_id = " + blogid + " AND user_id = " + userID + " ";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, sqlcon);
                    int existingLikes = (int)checkCmd.ExecuteScalar();
                    if (existingLikes == 0)
                    {
                        // The user hasn't liked this post, so insert the like record
                        string insertQuery = "INSERT INTO [myBlog].[dbo].[tbl_like_dislike] (Blog_id, user_id, isLike) VALUES (" + blogid + ", " + userID + ", 1)";
                        SqlCommand insertCmd = new SqlCommand(insertQuery, sqlcon);
                        int rowsAffected = insertCmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            btnLike.ImageUrl = "../blog/images/like_blue.png";
                        }
                    }
                    else if (existingLikes > 0)
                    {
                        string insertQuery = "UPDATE [myBlog].[dbo].[tbl_like_dislike] SET [isLike] = 1 WHERE Blog_id = " + blogid + " AND user_id = " + userID + " ";
                        SqlCommand insertCmd = new SqlCommand(insertQuery, sqlcon);
                        int rowsAffected = insertCmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            try
                            {
                                btnLike.ImageUrl = "../blog/images/like_blue.png"; // Set the image after liking the post
                                string checkQuery1 = "SELECT COUNT(*) FROM [myBlog].[dbo].[tbl_like_dislike] WHERE Blog_id = " + blogid + " AND user_id = " + userID + " ";
                                int existingLikes1 = (int)checkCmd.ExecuteScalar();
                                if (existingLikes1 > 0)
                                {
                                    btnLike.ImageUrl = "../blog/images/like_blue.png"; // Set the image after liking the post
                                    Response.Write("<script>alert('You are already liked this post.')</script>");
                                    btnLike.Enabled = false;
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Error");
                            }

                        }
                    }
                    sqlcon.Close();
                }
                else {
                   
                    Response.Redirect("../webUser/login.aspx");
                    Response.Write("<script>alert('Sorry.!! Firstly You have to LOGIN Your Accout.. ')</script>");
                }

            }
        }
    }
    public long GetPostUserID(string postID)
    {
        long userID = 0;
        string postid = Request.QueryString["post_id"];

        SqlConnection sqlcon = new SqlConnection(strcon);
        string query = "SELECT [Post_Creator] FROM [myBlog].[dbo].[tbl_posts] WHERE [Blog_id] = " + postid + " ";
        SqlCommand cmd = new SqlCommand(query, sqlcon);
        sqlcon.Open();
        object result = cmd.ExecuteScalar();
        if (result != null)
        {
            userID = Convert.ToInt64(result);
        }
        return userID;
    }

    protected void ddl_show_details_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        ImageButton deltButton = e.Item.FindControl("dltbtn") as ImageButton;
        long UserID = GetPostUserID(postid);

        if (UserID == Convert.ToInt64(Session["userID"]))
        {
            deltButton.Visible = true;
        }
        else
        {
            deltButton.Visible = false;
        }
    }

    protected void dltbtn_Click(object sender, ImageClickEventArgs e)
    {
        string postid = Request.QueryString["post_id"];
        long UserID = GetPostUserID(postid);
        if (Convert.ToInt64(Session["userID"]) > 0)
        {
            if (UserID == Convert.ToInt64(Session["userID"]))
            {
                SqlConnection sqlcon = new SqlConnection(strcon);
                sqlcon.Open();
                SqlTransaction transaction = sqlcon.BeginTransaction();

                try
                {
                    // 1. Delete comments related to the post
                    string deleteCommentsQuery = @"DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = " + postid + " AND [Comment_creator] =" + UserID + "";
                    using (SqlCommand deleteCommentsCmd = new SqlCommand(deleteCommentsQuery, sqlcon, transaction))
                    {
                        deleteCommentsCmd.ExecuteNonQuery();
                    }

                    // 2. Delete likes/dislikes related to the post
                    string deleteLikesDislikesQuery = @"DELETE FROM [myBlog].[dbo].[tbl_like_dislike] WHERE [Blog_id] =" + postid + " ";
                    using (SqlCommand deleteLikesDislikesCmd = new SqlCommand(deleteLikesDislikesQuery, sqlcon, transaction))
                    {
                        deleteLikesDislikesCmd.ExecuteNonQuery();
                    }

                    // 3. Delete the post
                    string deletePostQuery = @"DELETE FROM [myBlog].[dbo].[tbl_posts] WHERE [Blog_id] =" + postid + " ";
                    using (SqlCommand deletePostCmd = new SqlCommand(deletePostQuery, sqlcon, transaction))
                    {
                        deletePostCmd.ExecuteNonQuery();
                    }

                    // If everything is successful, commit the transaction
                    transaction.Commit();
                    Response.Redirect("all_posts.aspx");
                }
                catch (Exception ex)
                {
                    // An error occurred, rollback the transaction
                    transaction.Rollback();
                    // Handle the exception or log it
                }

            }
        }
        else
        {
            Response.Redirect("../webUser/login.aspx");
        }
    }
    public long GetCommentID(long cmmtid)
    {
        long cmmt_creatorID = 0;
        blogid = Convert.ToInt64(Request.QueryString["post_id"]);

        SqlConnection sqlcon = new SqlConnection(strcon);
        string query = "SELECT [Comment_creator] FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = " + blogid + " AND [comment_id]=" + cmmtid;
        SqlCommand cmd = new SqlCommand(query, sqlcon);
        sqlcon.Open();
        object result = cmd.ExecuteScalar();
        if (result != null)
        {
            cmmt_creatorID = Convert.ToInt64(result);
        }
        return cmmt_creatorID;
    }
    //protected void cmmtdltbtn_Click(object sender, ImageClickEventArgs e)
    //{
    //    blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
    //    long UserID = GetCommentID();

    //    if (UserID == Convert.ToInt64(Session["userID"]))
    //    {
    //        SqlConnection sqlcon = new SqlConnection(strcon);
    //        long cmmt_id = Convert.ToInt64(Session["cmmt_id"]);
    //        long userID = Convert.ToInt64(Session["userID"]);
    //        string deleteQuery = "DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = " + blogid + " AND [Comment_creator] = " + userID + " AND [comment_id] =" + cmmt_id + " ";
    //        SqlCommand cmd = new SqlCommand(deleteQuery, sqlcon);
    //        sqlcon.Open();
    //        int rowsAffected = cmd.ExecuteNonQuery();
    //        sqlcon.Close();
    //        if (rowsAffected > 0)
    //        {
    //            fetchdata();
    //        }

    //        fetchdata();
    //    }
    //}
    protected void lnkReply_Click(object sender, EventArgs e)
    {
        LinkButton lnkReply = (LinkButton)sender;
        string commentId = lnkReply.CommandArgument;

        // Now you have the comment ID (commentId), and you can use it as needed.
        // For example, you might want to store it in a Session variable.
        Session["cmmtid"] = commentId;

        MPE.Show();

    }
    protected void btn_rply_submit_Click1(object sender, EventArgs e)
    {
        string rereply = "";
        long userID = Convert.ToInt32(Session["userID"]);
        if (userID > 0)
        {
            long cmmt_id = Convert.ToInt32(Session["cmmtid"]);
            blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
            if (blogid > 0)
            {
                string reply = txt_rply.Text.Trim();
                rereply = "Re: " + reply;
            }
            SqlConnection sqlcon = new SqlConnection(strcon);
            string strcmd = @"INSERT INTO [myBlog].[dbo].[tbl_cmmt] ([comment],[Comment_creator],[post_id],[comment_Date],[parent_id]) VALUES ('" + rereply + "'," + userID + "," + blogid + ",getdate()," + cmmt_id + ")";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            int i = sqlcmd.ExecuteNonQuery();
            if (i > 0)
            {
                txt_rply.Text = string.Empty;
                string postid = Request.QueryString["post_id"];
                Response.Redirect("Single_post.aspx?post_id=" + postid);

            }
        }
        else
        {
            Response.Redirect("../webUser/login.aspx");
        }
    }
    public DataTable fetchNestedComment(long parn_id)
    {
        long userID = Convert.ToInt32(Session["userID"]);
        blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"SELECT 
                            cm.[comment_id],
                            cm.[comment],
                            cm.[Comment_creator],
                            cm.[comment_Date],
                            cm.[parent_id],
                            cm.[is_like],
                            cm.[is_dislike],
                            cm.[is_deleted],
                            cm.[post_id],
                            usr.[userPicPath],
                            usr.[firstName],
                            usr.[lastName],
                            (SELECT firstName + ' ' + lastName FROM tbl_Users WHERE userID = (SELECT [Comment_creator] FROM tbl_cmmt WHERE comment_id = cm.parent_id)) AS UsrName,
                            COALESCE([isLike], 0) AS nestedCommentIsLike
                        FROM 
                            [dbo].[tbl_cmmt] cm
                        INNER JOIN 
                            tbl_Users usr ON cm.[Comment_creator] = usr.userID
                        LEFT JOIN 
                             [myBlog].[dbo].[tbl_cmmt_like] likecmt 
                                ON cm.[comment_id] = likecmt.[cmmt_id] AND likecmt.[user_id] = " + userID + " AND likecmt.[blog_id] = " + blogid + " WHERE cm.parent_id = " + parn_id;

        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataTable ds = new DataTable();
        sqlad.Fill(ds);

        return ds;
    }
    protected void dtalist_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        DataRowView drv = e.Item.DataItem as DataRowView;
        DataTable dt = fetchNestedComment((long)drv["comment_id"]);
        DataList dl = e.Item.FindControl("dtalistReplies") as DataList;
        ImageButton imgDel = e.Item.FindControl("cmmtdltbtn") as ImageButton;
       long user_id = Convert.ToInt64(Session["userid"]);
        dl.DataSource = dt;
        dl.DataBind();
        if (user_id == uID)
        {
            imgDel.Visible = true;
        }
        else
        {
            imgDel.Visible = false;
        }
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            SqlConnection sqlcon = new SqlConnection(strcon);
            blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
            string updateQuery = "UPDATE [myBlog].[dbo].[tbl_cmmt] " +
                                 "SET [is_like] = COALESCE(likeCount, 0) " +
                                 "FROM [myBlog].[dbo].[tbl_cmmt] c " +
                                 "LEFT JOIN (" +
                                 "    SELECT cmmt_id, COUNT(*) AS likeCount " +
                                 "    FROM [myBlog].[dbo].[tbl_cmmt_like] " +
                                 "    WHERE isLike = 1 " +
                                 "    GROUP BY cmmt_id" +
                                 ") cl ON c.[comment_id] = cl.[cmmt_id] " +
                                 "WHERE c.[post_id] = " + blogid;

            SqlCommand updateCmd = new SqlCommand(updateQuery, sqlcon);
            sqlcon.Open();
            int rowsAffected = updateCmd.ExecuteNonQuery();

            long commentId = (long)drv["comment_id"];
            Session.Add("cmmtDLTid", commentId);
            // long id= GetCommentID(commentId);
            long postId = Convert.ToInt64(drv["post_id"]);

            string countQuery = "SELECT cm.post_id, cm.[comment_id], COUNT(cl.cmmt_id) AS total_likes FROM [dbo].[tbl_cmmt] cm LEFT JOIN [myBlog].[dbo].[tbl_cmmt_like] cl ON cm.[comment_id] = cl.cmmt_id WHERE cm.parent_id = 0 AND cm.[comment_id] = " + commentId + " AND cm.post_id = " + blogid + " GROUP BY cm.post_id, cm.[comment_id]";

            SqlDataAdapter adp = new SqlDataAdapter(countQuery, sqlcon);
            adp.SelectCommand.Parameters.AddWithValue("@cmmtId", commentId);

            DataSet ds = new DataSet();
            adp.Fill(ds);

            Label LabelLike = (Label)e.Item.FindControl("LabelLike");

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                LabelLike.Text = ds.Tables[0].Rows[0]["total_likes"].ToString();
                // UpdatePanel2.Update();
            }
            else
            {
                LabelLike.Text = "0"; // or any default value you want to set
                // UpdatePanel2.Update();
            }
        }
    }
    protected void lnkReply2_Click(object sender, EventArgs e)
    {
        LinkButton lnkReply = (LinkButton)sender;
        string commentId = lnkReply.CommandArgument;

        // Now you have the comment ID (commentId), and you can use it as needed.
        // For example, you might want to store it in a Session variable.
        Session["cmmtid"] = commentId;

        MPE.Show();
    }
    protected void cmmtLikebtn_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton cmmtLikebtn = (ImageButton)sender;
        string commentId = cmmtLikebtn.CommandArgument.ToString();
        Session.Add("commentId", commentId);
        blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
        SqlConnection sqlcon = new SqlConnection(strcon);
        long userid = Convert.ToInt64(Session["userid"]);
        if (userid>0)
        {
            // Toggle the islike value or insert/delete a new record
            int updatedIsLikeValue = GetUpdatedIsLikeValue(commentId, userid, blogid);
            if (updatedIsLikeValue > 0)
            {
                // Update the like status or insert/delete a new record
                string updatequery = "UPDATE [myblog].[dbo].[tbl_cmmt_like] SET islike = " + updatedIsLikeValue + " WHERE cmmt_id = " + commentId + " AND user_id = " + userid + " AND blog_id =" + blogid;
                SqlCommand updatecmd = new SqlCommand(updatequery, sqlcon);

                sqlcon.Open();
                int rowsAffected = updatecmd.ExecuteNonQuery();
                sqlcon.Close();

                if (rowsAffected > 0)
                {
                    fetchdata();

                }
            }
            else
            {
                fetchdata();

            }
        }
        else
        {
            Response.Redirect("../webUser/login.aspx");
        }
    }
    private int GetUpdatedIsLikeValue(string commentId, long userId, long blogId)
    {
        SqlConnection sqlcon = new SqlConnection(strcon);

        // Check if the user has already liked the comment
        string checkquery = "SELECT COUNT(*) FROM [myblog].[dbo].[tbl_cmmt_like] WHERE cmmt_id = " + commentId + " AND user_id = " + userId + " AND blog_id =" + blogId;
        SqlCommand checkcmd = new SqlCommand(checkquery, sqlcon);

        sqlcon.Open();
        int existingLikes = (int)checkcmd.ExecuteScalar();
        sqlcon.Close();

        if (existingLikes == 0)
        {
            // Insert the new record
            string insertquery = "INSERT INTO [myblog].[dbo].[tbl_cmmt_like] (islike, user_id, blog_id, cmmt_id) VALUES (1, " + userId + ", " + blogId + ", " + commentId + ")";
            SqlCommand insertcmd = new SqlCommand(insertquery, sqlcon);

            sqlcon.Open();
            insertcmd.ExecuteNonQuery();
            sqlcon.Close();

            return 1; // Return 1 as the new isLike value
        }
        else
        {
            // User has already liked the comment, delete the existing record
            string deletequery = "DELETE FROM [myblog].[dbo].[tbl_cmmt_like] WHERE cmmt_id = " + commentId + " AND user_id = " + userId + " AND blog_id =" + blogId;
            SqlCommand deletecmd = new SqlCommand(deletequery, sqlcon);

            sqlcon.Open();
            deletecmd.ExecuteNonQuery();
            sqlcon.Close();

            return 0; // Return 0 as the isLike value remains 0
        }
    }
    private int GetNestedLikeCmmt(string commentId, long userId, long blogId)
    {
        SqlConnection sqlcon = new SqlConnection(strcon);
         
             // Retrieve the parent_id of the comment
             string getParentIdQuery = "SELECT parent_id FROM [myblog].[dbo].[tbl_cmmt] WHERE comment_id = " + commentId;
             SqlCommand getParentIdCmd = new SqlCommand(getParentIdQuery, sqlcon);

             sqlcon.Open();
             object parentIdResult = getParentIdCmd.ExecuteScalar();
             long parentId = (parentIdResult != null) ? Convert.ToInt64(parentIdResult) : 0;
             sqlcon.Close();

             // Check if the user has already liked the comment (considering parent_id)
             string checkquery = "SELECT COUNT(*) FROM [myblog].[dbo].[tbl_cmmt_like] WHERE cmmt_id = " + commentId + " AND user_id = " + userId + " AND blog_id =" + blogId + " AND parent_id = " + parentId;
             SqlCommand checkcmd = new SqlCommand(checkquery, sqlcon);

             sqlcon.Open();
             int existingLikes = (int)checkcmd.ExecuteScalar();
             sqlcon.Close();

             if (existingLikes == 0)
             {
                 // Insert the new record
                 string insertquery = "INSERT INTO [myblog].[dbo].[tbl_cmmt_like] (islike, user_id, blog_id, cmmt_id, parent_id) VALUES (1, " + userId + ", " + blogId + ", " + commentId + ", " + parentId + ")";
                 SqlCommand insertcmd = new SqlCommand(insertquery, sqlcon);

                 sqlcon.Open();
                 insertcmd.ExecuteNonQuery();
                 sqlcon.Close();

                 return 1; // Return 1 as the new isLike value
             }
             else
             {
                 // User has already liked the comment, delete the existing record
                 string deletequery = "DELETE FROM [myblog].[dbo].[tbl_cmmt_like] WHERE cmmt_id = " + commentId + " AND user_id = " + userId + " AND blog_id =" + blogId + " AND parent_id = " + parentId;
                 SqlCommand deletecmd = new SqlCommand(deletequery, sqlcon);

                 sqlcon.Open();
                 deletecmd.ExecuteNonQuery();
                 sqlcon.Close();

                 return 0; // Return 0 as the isLike value remains 0
             }
         
    }
    protected void cmmtLikeNestedbtn_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton cmmtLikebtn = (ImageButton)sender;
        string commentId = cmmtLikebtn.CommandArgument.ToString();

        blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
        SqlConnection sqlcon = new SqlConnection(strcon);
        long userid = Convert.ToInt64(Session["userid"]);
        if (userid >0)
        {
            int updatedIsLikeValue = GetNestedLikeCmmt(commentId, userid, blogid);
            if (updatedIsLikeValue > 0)
            {
                fetchdata();
                //string postid = Request.QueryString["post_id"];
                //Response.Redirect("single_post.aspx?post_id=" + postid);
            }
            else
            {
                fetchdata();
                //string postid = Request.QueryString["post_id"];
                //Response.Redirect("single_post.aspx?post_id=" + postid);
            }
        }
        else
        {
        Response.Redirect("../webUser/login.aspx");
        }

    }
    protected void dtalistReplies_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        DataRowView drv = e.Item.DataItem as DataRowView;
        ImageButton imgDel = e.Item.FindControl("NestedCmmtDltBtn") as ImageButton;
        long user_id = Convert.ToInt64(Session["userid"]);
        
        if (user_id == uID)
        {
            imgDel.Visible = true;
        }
        else
        {
            imgDel.Visible = false;
        }
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            long parentId = (long)drv["parent_id"];
            long cmmtId = (long)drv["comment_id"];
            SqlConnection sqlcon = new SqlConnection(strcon);
            blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
            string updatequery = @"UPDATE [myBlog].[dbo].[tbl_cmmt]
                                    SET [is_like] = COALESCE(likeCount, 0)
                                    FROM [myBlog].[dbo].[tbl_cmmt] c
                                    LEFT JOIN (
                                        SELECT cm.parent_id, cm.post_id, COUNT(cl.[cmmt_id]) AS likeCount
                                        FROM [myBlog].[dbo].[tbl_cmmt] cm
                                        LEFT JOIN [myBlog].[dbo].[tbl_cmmt_like] cl ON cm.comment_id = cl.[cmmt_id]
                                        WHERE cm.parent_id != 0
                                        GROUP BY cm.parent_id, cm.post_id
                                    ) cl ON c.parent_id = cl.parent_id AND c.post_id = cl.post_id
                                    WHERE c.parent_id != 0 AND c.post_id =" + blogid;
            SqlCommand sqlcmd = new SqlCommand(updatequery, sqlcon);
            sqlcon.Open();
            int i = sqlcmd.ExecuteNonQuery();

            string strcmd = @"SELECT COUNT(cl.[cmmt_id]) AS total_likes FROM [myBlog].[dbo].[tbl_cmmt] cm LEFT JOIN [myBlog].[dbo].[tbl_cmmt_like] cl ON cm.comment_id = cl.[cmmt_id] WHERE cm.parent_id =" + parentId + " AND cm.post_id = " + blogid + " AND cm.[comment_id]=" + cmmtId + "";
            SqlDataAdapter adp = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            Label labelNestedLike = (Label)e.Item.FindControl("labelNestedLike");

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                labelNestedLike.Text = ds.Tables[0].Rows[0]["total_likes"].ToString();

            }
            else
            {
                labelNestedLike.Text = "0";
            }
        }
    }
    public long getuserid()
    {
        long userdltpostID = 0;

        using (SqlConnection sqlccon = new SqlConnection(strcon)) // Assuming strcon is your connection string
        {
            sqlccon.Open();

            blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
            string strcmd = @"SELECT [Post_Creator]  FROM [myBlog].[dbo].[tbl_posts] WHERE [Blog_id]=" + blogid;

            using (SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlccon))
            {
                DataSet ds = new DataSet();
                sqlad.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    userdltpostID = Convert.ToInt64(ds.Tables[0].Rows[0]["Post_Creator"].ToString());
                }
            }
        }

        return userdltpostID;
    }
    protected void cmmtdltbtn_Click(object sender, ImageClickEventArgs e)
    {

        ImageButton cmmtdltbtn = (ImageButton)sender;
        string commentId = cmmtdltbtn.CommandArgument.ToString();
        long cmmtID = Convert.ToInt64(commentId);
        long UserID = GetCommentID(cmmtID);
        long userdltpostID = getuserid();
        if (Convert.ToInt64(Session["userID"]) != null)
        {
            if (UserID == Convert.ToInt64(Session["userID"]) || Convert.ToInt64(Session["userID"]) == userdltpostID)
            {
                //  SqlConnection sqlcon = new SqlConnection(strcon);

                using (SqlConnection sqlcon = new SqlConnection(strcon))
                {
                    sqlcon.Open();

                    // Delete the top-level comment and its related nested comments
                    RecursiveDeleteComment(sqlcon, blogid, cmmtID);

                    // Fetch data after the delete operation
                    fetchdata();

                    string postid = Request.QueryString["post_id"];
                    Response.Redirect("single_post.aspx?post_id=" + postid);
                }
            }
        }
        else
        {
            Response.Redirect("../webUser/login.aspx");
        }
    }
    private void RecursiveDeleteComment(SqlConnection sqlcon, long blogId, long commentId)
    {
        // Delete associated likes for the current comment
        if (Convert.ToInt64(Session["userID"]) > 0)
        {
            string likeDeleteQuery = "DELETE FROM [myBlog].[dbo].[tbl_cmmt_like] WHERE [blog_id] = @blogId AND [cmmt_id] = @commentId";
            using (SqlCommand likeCmd = new SqlCommand(likeDeleteQuery, sqlcon))
            {
                likeCmd.Parameters.AddWithValue("@blogId", blogId);
                likeCmd.Parameters.AddWithValue("@commentId", commentId);
                likeCmd.ExecuteNonQuery();
            }

            // Get nested comments using a separate SqlConnection
            using (SqlConnection nestedSqlcon = new SqlConnection(strcon))
            {
                nestedSqlcon.Open();

                string nestedCommentsQuery = "SELECT [comment_id] FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = @blogId AND [parent_id] = @commentId";
                using (SqlCommand nestedCmd = new SqlCommand(nestedCommentsQuery, nestedSqlcon))
                {
                    nestedCmd.Parameters.AddWithValue("@blogId", blogId);
                    nestedCmd.Parameters.AddWithValue("@commentId", commentId);

                    using (SqlDataReader reader = nestedCmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            long nestedCommentId = Convert.ToInt64(reader["comment_id"]);
                            // Recursive call to delete nested comments
                            RecursiveDeleteComment(sqlcon, blogId, nestedCommentId);
                        }
                    }
                }
            }

            // Delete the current comment
            string deleteQuery = "DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = @blogId AND [comment_id] = @commentId";
            using (SqlCommand cmd = new SqlCommand(deleteQuery, sqlcon))
            {
                cmd.Parameters.AddWithValue("@blogId", blogId);
                cmd.Parameters.AddWithValue("@commentId", commentId);
                cmd.ExecuteNonQuery();
            }
        }
        else
        {
            Response.Redirect("../webUser/login.aspx");
        }
    }


    protected void NestedCmmtDltBtn_Click1(object sender, ImageClickEventArgs e)
    {
        long userid = Convert.ToInt64(Session["userid"]);
        if (userid>0)
        {
            long userdltpostID = getuserid();
            blogid = Convert.ToInt64(Request.QueryString["post_id"].ToString());
            ImageButton cmmtdltbtn = (ImageButton)sender;
            string commentId = cmmtdltbtn.CommandArgument.ToString();
            long cmmtID = Convert.ToInt64(commentId);
            long parentId = 0;
            long creatorID = 0;

            SqlConnection sqlcon = new SqlConnection(strcon);
            blogid = Convert.ToInt64(Request.QueryString["post_id"]);
            string query = "SELECT [Comment_creator], [parent_id] FROM [myBlog].[dbo].[tbl_cmmt] WHERE  [post_id] =" + blogid + " AND [comment_id] = " + cmmtID;
            SqlDataAdapter sqlad = new SqlDataAdapter(query, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                creatorID = Convert.ToInt64(ds.Tables[0].Rows[0]["Comment_creator"].ToString());
                parentId = Convert.ToInt64(ds.Tables[0].Rows[0]["parent_id"].ToString());
            }
            if (creatorID == Convert.ToInt64(Session["userID"]) || Convert.ToInt64(Session["userID"]) == userdltpostID)
            {

                // long cmmt_id = Convert.ToInt64(Session["cmmt_id"]);
                long userID = Convert.ToInt64(Session["userID"]);
                string deleteQuery = "DELETE FROM [myBlog].[dbo].[tbl_cmmt] WHERE [post_id] = " + blogid + " AND [Comment_creator] = " + userID + " AND [comment_id] =" + cmmtID + " AND [parent_id]=" + parentId + " ";
                SqlCommand dltcmd = new SqlCommand(deleteQuery, sqlcon);
                sqlcon.Open();
                int rowsAffected = dltcmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {

                    fetchdata();
                    //string postid = Request.QueryString["post_id"];
                    //Response.Redirect("Single_post.aspx?post_id=" + postid);
                    string likeDlt = @"DELETE FROM [myBlog].[dbo].[tbl_cmmt_like] WHERE [blog_id]=" + blogid + " AND [cmmt_id] =" + cmmtID + " AND [parent_id]=" + parentId + "";
                    SqlCommand sqlcmdlike = new SqlCommand(likeDlt, sqlcon);

                    int i = sqlcmdlike.ExecuteNonQuery();

                }
            }
        }
        else
        {
            Response.Redirect("../webUser/login.aspx");
        }
    }

}