﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class blog_blog_grid : System.Web.UI.Page
{
  
    protected void Page_Load(object sender, EventArgs e)
    {
        fetchAllPosts();
    }
    public void fetchAllPosts()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        string strcmd = @"SELECT 
                        tbl_posts.Blog_id,
                        tbl_posts.Post_title,
                        (case when len (tbl_posts.Post_description)>200 THEN SUBSTRING(tbl_posts.Post_description,1,200)+'....' ELSE tbl_posts.Post_description END) as Post_description,
                        tbl_posts.Post_Creator,
                        tbl_posts.Post_Category,
                        tbl_posts.Post_images,
                        tbl_posts.Created_date,
                        tbl_Category.catName,
                        COUNT(tbl_cmmt.comment) as countt FROM tbl_posts LEFT JOIN tbl_cmmt ON tbl_cmmt.post_id = tbl_posts.Blog_id 
                        LEFT JOIN tbl_Category ON tbl_Category.catID = tbl_posts.Post_Category GROUP BY tbl_posts.Blog_id,
                        tbl_posts.Post_title, tbl_posts.Post_description, tbl_posts.Post_Creator, tbl_posts.Post_Category,
                        tbl_posts.Post_images, tbl_posts.Created_date, tbl_Category.catName ORDER BY [Blog_id] DESC";
                            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlAllPosts.DataSource = ds;

            ddlAllPosts.DataBind();
           string pics_post=ds.Tables[0].Rows[0]["Post_images"].ToString();
           Session.Add("pics",pics_post);
        
        }
    }
}