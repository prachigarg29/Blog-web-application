﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class webUser_UserProfile : System.Web.UI.Page
{
    string strpss = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fetchData();
        }
    }
    public void fetchData()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        if (Session.Keys.Count > 0)
        {

            string email = Session["emailOfUser"].ToString();

            string strcmd = @"SELECT * FROM [dbo].[tbl_Users] where userEmail= '" + email + "'";
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);


            if (ds.Tables[0].Rows.Count > 0)
            {
                dlUserInfo.DataSource = ds;
                dlUserInfo.DataBind();
                dlUserInfo2.DataSource = ds;
                dlUserInfo2.DataBind();
                dlUserInfo3.DataSource = ds;
                dlUserInfo3.DataBind();

                txtName.Text = ds.Tables[0].Rows[0]["firstName"].ToString();
                txt_country.Text = ds.Tables[0].Rows[0]["country"].ToString();
                txt_address.Text = ds.Tables[0].Rows[0]["adress"].ToString();
                txt_phn.Text = ds.Tables[0].Rows[0]["phone_no"].ToString();
                txt_email.Text = ds.Tables[0].Rows[0]["userEmail"].ToString();
                txt_twitter_link.Text = ds.Tables[0].Rows[0]["twitter_profile"].ToString();
                txt_facebook_link.Text = ds.Tables[0].Rows[0]["facebook_profile"].ToString();
                txt_insta_link.Text = ds.Tables[0].Rows[0]["insta_profile"].ToString();
                txt_linkedin_link.Text = ds.Tables[0].Rows[0]["linkedin_profile"].ToString();
                string pic = ds.Tables[0].Rows[0]["userPicPath"].ToString();

                if (pic == "")
                {
                    pic = "../blog/images/noprofile (2).png";
                    Session.Add("userPicPath2", pic);
                }
                else
                {
                    Session.Add("userPicPath2", pic);
                }
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }

    }

    
    protected void btnProfileUpdates_Click(object sender, EventArgs e)
    {
        long userId = Convert.ToInt64(Session["userID"]);
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        string fname = txtName.Text.Trim();
        string email = txt_email.Text.Trim();
        string country = txt_country.Text.Trim();
        string address = txt_address.Text.Trim();
        
        //long phn =Convert.ToInt64(txt_phn.Text.Trim());
        string fprofile = txt_facebook_link.Text.Trim();
        string iprofile = txt_insta_link.Text.Trim();
        string tprofile = txt_twitter_link.Text.Trim();
        string lprofile = txt_linkedin_link.Text.Trim();
        string strPath = "";
        if (userprofile.HasFile)
        {
            strPath = "..\\Images\\" + userprofile.FileName;
            string actPath = Server.MapPath(strPath);
            userprofile.SaveAs(actPath);
        }
        string strcmd = @"UPDATE [dbo].[tbl_Users] set [userEmail] ='" + email + "',[userPicPath]='"+strPath+"',[firstName]='" + fname + "',[country]='" + country + "', adress='" + address + "',[twitter_profile]='" + tprofile + "',[facebook_profile]='" + fprofile + "',[insta_profile]='" + iprofile + "',[linkedin_profile]='" + lprofile + "' where [userID] =" + userId;
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        int i = sqlcmd.ExecuteNonQuery();
        if (i > 0)
        {
            Response.Redirect("UserProfile.aspx");
          
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        chng_psswd();
    }
    public void chng_psswd()
    {
        string email = Session["emailOfUser"].ToString();
        string pass = Session["psswd"].ToString();
        //if (txt_current_psswd.Text == pass)
        //{
            SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
            string strcmd = @"UPDATE [dbo].[tbl_Users] set [userPassword] ='" + txt_new_psswd.Text.Trim() + "' where [userEmail]='" + email + "'  ";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcon.Open();
            int i = sqlcmd.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("<script>alert('password chnge successfully!!!!!....')</script>");
            }
            
        //}
        //else
        //{
        //    Response.Write("<script>alert('current password is not correct !!!!!....')</script>");
        //}
        

    }
    public void new_psswd()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        long id = Convert.ToInt64(Session["userID"]);
        string email = Session["emailOfUser"].ToString();
        string strcmd = @"SELECT [userPassword] FROM [dbo].[tbl_Users]  where [userID] = "+id;
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        strpss = ds.Tables[0].Rows[0]["userPassword"].ToString();
        if (strpss == txt_current_psswd.Text)
        {
            Response.Write("<script>alert('PASSWORD MACHED')</script>");
            Button1.Enabled = true;        
        }
        else
        {
            Response.Write("<script>alert('PASSWORD NOT MACHED')</script>");
            Button1.Enabled = false;
        }
    }

    protected void txt_current_psswd_TextChanged(object sender, EventArgs e)
    {
        new_psswd();
    }

    protected void dltProfileBtn_Click(object sender, ImageClickEventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        string Upic="";
        long userId = Convert.ToInt64(Session["userID"]);
        string strcmd = @"UPDATE [dbo].[tbl_Users] set [userPicPath]='"+Upic+"' where [userID] =" + userId ;
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        int i = sqlcmd.ExecuteNonQuery();
        if (i > 0)
        {
            Response.Redirect("UserProfile.aspx");

        }
    }
}