﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class webUser_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fetchdata();
    }
    protected void lnkSignOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("login.aspx");
    }
    public void fetchdata()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
        long userid = Convert.ToInt64(Session["userID"]);
        string strcmd = @"select [userPicPath] from [myBlog].[dbo].[tbl_Users] where userID="+userid;
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd,sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count>0)
        {
            dtalistPic.DataSource = ds;
            dtalistPic.DataBind();
           // Response.Redirect("UserProfile.aspx");
        }
    }
}
