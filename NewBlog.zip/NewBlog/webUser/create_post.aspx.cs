﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
public partial class webUser_create_post : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            fetchCategories();
        }
    }
    protected void Submit_btn_Click(object sender, EventArgs e)
    {
        long creatorID = Convert.ToInt32(Session["userID"]);
        if (creatorID > 0)
        {
            SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);
            long catID = Convert.ToInt32(ddlCategories.SelectedValue);

            string strPath = "";
            if (flImage.HasFile)
            {
                strPath = "..\\Images\\" + flImage.FileName;
                string actPath = Server.MapPath(strPath);
                flImage.SaveAs(actPath);
            }

            string strcmd = @"INSERT INTO [dbo].[tbl_posts] ([Post_title], [Post_description], [Created_date], [Post_Category], [Post_Creator], [Post_images])
                          VALUES (@PostTitle, @PostDescription, GETDATE(), @PostCategory, @PostCreator, @PostImages)";

            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
            sqlcmd.Parameters.AddWithValue("@PostTitle", txt_post_title.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@PostDescription", txt_description.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@PostCategory", catID);
            sqlcmd.Parameters.AddWithValue("@PostCreator", creatorID);
            sqlcmd.Parameters.AddWithValue("@PostImages", strPath);

            try
            {
                sqlcon.Open();
                int i = sqlcmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Response.Write("<script>alert('inserted')</script>");
                    Response.Write("<script>setTimeout(function() {window.location.href='create_post.aspx';},100);</script>");
                    txt_description.Text = string.Empty;
                    txt_post_title.Text = string.Empty;
                    // string post_cat = "";
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (log or display error messages)
                Response.Write("<script>alert('Error: " + ex.Message + "')</script>");
            }
            finally
            {
                sqlcon.Close();
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }

    protected void Reset_btn_Click(object sender, EventArgs e)
    {
        txt_post_title.Text = "";
        txt_description.Text = "";
    }
    public void fetchCategories()
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);

        string strcmd = @"SELECT catID,[catName] FROM [myBlog].[dbo].[tbl_Category]";
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd,sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlCategories.DataSource = ds;
            ddlCategories.DataTextField = "catName";
            ddlCategories.DataValueField = "catID";
            ddlCategories.DataBind();
            
            

        }
    }
}