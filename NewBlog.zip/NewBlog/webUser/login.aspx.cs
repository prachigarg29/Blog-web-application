﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class webUser_login : System.Web.UI.Page
{
    string strcon = @"Data Source=PRACHI\PRACHMSSQLSERVER;Initial Catalog=myBlog;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e){
     using (SqlConnection sqlcon = new SqlConnection(strcon))
        {
            string strcmd = @"SELECT [userID],[userEmail],[userPicPath],[firstName],[lastName],[userPassword] FROM [dbo].[tbl_Users] WHERE userEmail=@UserEmail AND userPassword=@UserPassword";
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            sqlad.SelectCommand.Parameters.AddWithValue("@UserEmail", txt_email.Text.Trim());
            sqlad.SelectCommand.Parameters.AddWithValue("@UserPassword", txt_psswd.Text.Trim());

            DataSet ds = new DataSet();
            try
            {
                sqlcon.Open();
                sqlad.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    string email = ds.Tables[0].Rows[0]["userEmail"].ToString();
                    Session.Add("emailOfUser", email);
                    string userID = ds.Tables[0].Rows[0]["userID"].ToString();
                    Session.Add("userID", userID);
                    string psswd = ds.Tables[0].Rows[0]["userPassword"].ToString();
                    string pic = ds.Tables[0].Rows[0]["userPicPath"].ToString();
                    Session.Add("Pic", pic);
                    Session.Add("psswd", psswd);
                    string uname = ds.Tables[0].Rows[0]["firstName"].ToString();
                    Session.Add("name", uname);
                    string lname = ds.Tables[0].Rows[0]["lastName"].ToString();
                    Session.Add("lname", lname);
                    Response.Redirect("UserProfile.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Login failed')</script>");
                }
            }
            catch (Exception ex)
            {
                // Handle the exception (log or display an error message)
              //  Response.Write($"<script>alert('An error occurred: {ex.Message}')</script>");
            }
        }
    }
}