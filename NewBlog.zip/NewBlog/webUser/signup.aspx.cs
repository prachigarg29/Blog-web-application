﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class webUser_signup : System.Web.UI.Page
{
  
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(clsUtility.myConn);

        string strcmd = @"INSERT INTO [myBlog].[dbo].[tbl_Users] ([firstName],[lastName],[userEmail],[userPassword]) VALUES('" + txt_first_name.Text.Trim() + "','" + txt_last_name.Text.Trim() + "','" + txt_email.Text.Trim() + "','" + txt_psswd.Text.Trim() + "')";

        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        int i = sqlcmd.ExecuteNonQuery();
        if (i > 0)
        {
            Response.Write("<script>alert('inserted')</script>");
            Response.Redirect("login.aspx");
            txt_first_name.Text = string.Empty;
            txt_last_name.Text = string.Empty;
            txt_email.Text = string.Empty;
            txt_psswd.Text = string.Empty;
            
        }
    }
}