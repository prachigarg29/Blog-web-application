﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

/// <summary>
/// Summary description for clsEntity
/// </summary>
public static class clsEntity
{

    public static string _Conn
    {
        get { return "Data Source=PRACHI\\PRACHMSSQLSERVER;Initial Catalog=StuLibrary;Integrated Security=True"; }
        
    }
    
}