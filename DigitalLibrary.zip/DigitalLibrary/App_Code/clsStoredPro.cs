﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsStoredPro
/// </summary>
public class clsStoredPro
{
	public clsStoredPro()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}