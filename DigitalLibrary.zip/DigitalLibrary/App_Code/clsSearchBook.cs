﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
/// <summary>
/// Summary description for clsSearchBook
/// </summary>
public class clsSearchBook
{
    #region property
    public string _srchBook { get; set; }
    #endregion
    public DataSet searchbook()
    {
        SqlParameter[] sqlpar = new SqlParameter[2];
        sqlpar[0] = new SqlParameter("@search",SqlDbType.NVarChar);
        sqlpar[0].Value = _srchBook;

        sqlpar[1] = new SqlParameter("@cmd", SqlDbType.VarChar);
        sqlpar[1].Value = "search";
        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(clsEntity._Conn, CommandType.StoredProcedure, "SearchBookPro", sqlpar);
        return ds;
    }
}