﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
/// <summary>
/// Summary description for Class1
/// </summary>
public class ManageStudent
{
    #region property
    public string _txtName { get; set; }
    public string _email { get; set; }
    public string _psswd { get; set; }
    public string _rollno { get; set; }
    public string _course { get; set; }
    public string _sem { get; set; }
    #endregion
    //string strcon = "";
    //public ManageStudent()
    //{
    //    strcon = @"Data Source=PRACHI\PMSSQLSERVER;Initial Catalog=StuLibrary;Integrated Security=True";
       
    //}
    public int createAC()
    {
        SqlParameter[] sqlpram = new SqlParameter[7];

        sqlpram[0] = new SqlParameter("@Name", SqlDbType.VarChar);
        sqlpram[0].Value = _txtName;

        sqlpram[1] = new SqlParameter("@Email", SqlDbType.NVarChar);
        sqlpram[1].Value = _email;

        sqlpram[2] = new SqlParameter("@psswd", SqlDbType.NVarChar);
        sqlpram[2].Value = _psswd;

        sqlpram[3] = new SqlParameter("@rollNo", SqlDbType.BigInt);
        sqlpram[3].Value = _rollno;

        sqlpram[4] = new SqlParameter("@course", SqlDbType.NVarChar);
        sqlpram[4].Value = _course;

        sqlpram[5] = new SqlParameter("@sem", SqlDbType.NVarChar);
        sqlpram[5].Value = _sem;

        sqlpram[6] = new SqlParameter("@cmd", SqlDbType.VarChar);
        sqlpram[6].Value = "signup";


        int res=SqlHelper.ExecuteNonQuery(clsEntity._Conn, CommandType.StoredProcedure, "managestuPro", sqlpram);
        return res;

    }
    public DataSet Stulogin()
    {
        //SqlConnection sqlcon = new SqlConnection(strcon);
        //string strcmd = @"SELECT * FROM [dbo].[tbl_stu_info] WHERE [Stu_email]='" + LoginEmail + "' AND [Stu_psswd]='" + loginpsswd + "'";
        //SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        SqlParameter[] sqlpram = new SqlParameter[3];
        sqlpram[0] = new SqlParameter("@Email", SqlDbType.NVarChar);
        sqlpram[0].Value = _email;

        sqlpram[1] = new SqlParameter("@psswd", SqlDbType.NVarChar);
        sqlpram[1].Value = _psswd;

        sqlpram[2] = new SqlParameter("@cmd", SqlDbType.VarChar);
        sqlpram[2].Value = "signin";

        DataSet ds = new DataSet();
        ds = SqlHelper.ExecuteDataset(clsEntity._Conn, CommandType.StoredProcedure, "managestuPro", sqlpram);

        return ds;
        
    }
}