﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class LoginRegister : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void loginsubmit_Click(object sender, EventArgs e)
    {
        ManageStudent objcls = new ManageStudent();
        objcls._email = LoginTxtEmail.Text.Trim();
        objcls._psswd = LoginPsswd.Text.Trim();
        DataSet dsres = objcls.Stulogin();
        if (dsres.Tables[0].Rows.Count > 0)
        {
            LoginTxtEmail.Text = string.Empty;
            LoginPsswd.Text = string.Empty;
            long id = Convert.ToInt64(dsres.Tables[0].Rows[0]["Stu_id"].ToString());
            Session.Add("stuID", id);
            Session.Add("stuName", dsres.Tables[0].Rows[0]["Stu_Name"].ToString());
            Session.Add("stuPic", dsres.Tables[0].Rows[0]["stu_pic"].ToString());
            Response.Write("<script>alert('login successfully...')</script>");
          
            SqlConnection con = new SqlConnection(clsEntity._Conn);
            string strUpTime = @"update [StuLibrary].[dbo].[tbl_stu_info] set [StuLoginTime]=getdate() where [Stu_id]=" + id;
            SqlCommand sqlcmd = new SqlCommand(strUpTime, con);
            con.Open();
            int i = sqlcmd.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("<script>alert('logout Time updated')</script>");
            }
            Response.Redirect("HomePage.aspx");
        }
        else
        {
            Response.Write("<script>alert('login Failed...')</script>");
            LoginTxtEmail.Text = string.Empty;
            LoginPsswd.Text = string.Empty;
        }
    }
}