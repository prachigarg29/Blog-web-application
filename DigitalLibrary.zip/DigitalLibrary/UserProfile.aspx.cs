﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class UserProfile : System.Web.UI.Page
{
    string strcon = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    long Sid = 0;
    string Oldpsswd = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            pnlOverview.Visible = true;
            pnledit.Visible = false;
            pnlchngpsswd.Visible = false;
            Sid = Convert.ToInt64(Session["stuID"]);
            SqlConnection con = new SqlConnection(strcon);
            string strcmd = @"select [Stu_id],[Stu_Name],[Stu_email],[Stu_psswd],[stu_rollNo],[stu_course],[stu_sem],[stu_pic] FROM [StuLibrary].[dbo].[tbl_stu_info] where [Stu_id]=" + Sid;
            SqlDataAdapter ad = new SqlDataAdapter(strcmd, con);
            DataSet ds = new DataSet();
            ad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dtalistProfile.DataSource = ds;
                dtalistProfile.DataBind();
                txtName.Text = ds.Tables[0].Rows[0]["Stu_Name"].ToString();
                txtEmail.Text = ds.Tables[0].Rows[0]["Stu_email"].ToString();
                txtcourse.Text = ds.Tables[0].Rows[0]["stu_course"].ToString();
                txtrollno.Text = ds.Tables[0].Rows[0]["stu_rollNo"].ToString();
                txtsem.Text = ds.Tables[0].Rows[0]["stu_sem"].ToString();
            }
        }
    }
    protected void editbtn_Click(object sender, EventArgs e)
    {
        pnledit.Visible = true;
        pnlOverview.Visible = false;
        pnlchngpsswd.Visible = false;
    }

    public void retriveData()
    {

    }

    protected void ChngepswdBtn_Click(object sender, EventArgs e)
    {
        pnlchngpsswd.Visible = true;
        pnledit.Visible = false;
        pnlOverview.Visible = false;
    }
    protected void Savebtn_Click(object sender, EventArgs e)
    {
        Sid = Convert.ToInt64(Session["stuID"]);
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strcmd = @"update [StuLibrary].[dbo].[tbl_stu_info] set [Stu_Name]='" + txtName.Text.Trim() + "',[Stu_email]='" + txtEmail.Text.Trim() + "',[stu_rollNo]=" + Convert.ToInt64(txtrollno.Text) + ",[stu_course]='" + txtcourse.Text.Trim() + "',[stu_sem]='" + txtsem.Text.Trim() + "' where [Stu_id]=" + Sid;
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        if (sqlcmd.ExecuteNonQuery() > 0)
        {
            Response.Redirect("UserProfile.aspx");
        }
    }
    protected void PsswdChnge_Click(object sender, EventArgs e)
    {
        Sid = Convert.ToInt64(Session["stuID"]);
        SqlConnection sqlcon = new SqlConnection(strcon);
        string strCheckOldpswd = @"select [Stu_psswd] from [StuLibrary].[dbo].[tbl_stu_info]  where [Stu_id]=" + Sid;
        SqlDataAdapter ad = new SqlDataAdapter(strCheckOldpswd, sqlcon);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
           Oldpsswd = ds.Tables[0].Rows[0]["Stu_psswd"].ToString();
           if (Oldpsswd == txtOldPswd.Text)
           {
               string updateNewPswd = @"update [StuLibrary].[dbo].[tbl_stu_info] set [Stu_psswd]='" + txtNewpsswd.Text.Trim() + "' where [Stu_id]=" + Sid;
               SqlCommand sqlcmd = new SqlCommand(updateNewPswd, sqlcon);
               sqlcon.Open();
               if (sqlcmd.ExecuteNonQuery() > 0)
               {
                   Response.Redirect("UserProfile.aspx");
               }
           }
           else
           {
               Response.Write("<script>alert('Old Password is Incorrect. Please Check it.')</script>");
           }
        }
        
    }
}