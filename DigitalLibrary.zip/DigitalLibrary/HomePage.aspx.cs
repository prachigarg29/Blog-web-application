﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using System.Text;
using PdfSharp.Pdf.Content;

using PdfSharp.Pdf.Content.Objects;

public partial class HomePage : System.Web.UI.Page
{
    string filePath = "";
    string fname = "";
    
    string fextension = "";
    string urlpath = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlBookShow.Visible = false;
        if (!IsPostBack)
        {
            using (SqlConnection con = new SqlConnection(clsEntity._Conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT [catID],[catName] FROM [StuLibrary].[dbo].[BookCategory] ORDER BY catName ASC", con))
                {
                    con.Open();
                    dropdownCat.DataSource = cmd.ExecuteReader();
                    dropdownCat.DataTextField = "catName";
                    dropdownCat.DataValueField = "catID";
                    dropdownCat.DataBind();
                    con.Close();
                    txtSearchBook.Text = string.Empty;
                }
            }
        }
    }

    void GetPdfPageCount(string filePath)
    {

        // Open the PDF file using PdfReader
        using (PdfDocument document = PdfReader.Open(filePath, PdfDocumentOpenMode.Import))
        {
            // Get the number of pages in the PDF document
            int pageCount = document.PageCount;
            Session.Add("leng", pageCount);
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(clsEntity._Conn))
            {
                string cmd = @"SELECT [BookID], [category], [title], [File], [URL], [fl_exten], [type_file], [StuId], [Book_Length], [AuthorName], [Edition], [Publisher], [bookImg]
                            FROM [StuLibrary].[dbo].[tbl_content]
                            WHERE [title] LIKE '%' + '" + txtSearchBook.Text.Trim() + "' + '%'";

                using (SqlCommand command = new SqlCommand(cmd, con))
                {
                    con.Open();
                    SqlDataAdapter sqlad = new SqlDataAdapter(command);
                    DataSet ds = new DataSet();
                    sqlad.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Session.Add("bookid", ds.Tables[0].Rows[0]["BookID"].ToString());

                        urlpath = ds.Tables[0].Rows[0]["URL"].ToString();
                        filePath = ds.Tables[0].Rows[0]["File"].ToString();
                       
                        databook.DataSource = ds;
                        databook.DataBind();
                        pnlBookShow.Visible = true;
                        //Session.Add("filepath", filePath);
                        GetPdfPageCount("C:\\Users\\Prachi garg\\Documents\\Visual Studio 2012\\Projects\\WFAELIB\\WFAELIB\\bin\\Debug"+filePath);

                        //  ProcessPdfFromFilePath(filePath);
                    }
                    else
                    {
                        Response.Write("No data found matching the query.");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }

    //protected void downloadbtn_Click(object sender, EventArgs e)
    //{
    //    // Check if Session["bookid"] is not null
    //    long stuid = Convert.ToInt64(Session["stuID"]);
    //    if (stuid > 0)
    //    {
    //        if (Session["bookid"] != null)
    //        {
    //            // Establish connection to the database
    //            SqlConnection con = new SqlConnection(clsEntity._Conn);
    //            try
    //            {
    //                con.Open();
    //                long bookid = Convert.ToInt64(Session["bookid"]);
    //                string strcmd = @"SELECT * FROM [StuLibrary].[dbo].[tbl_content] WHERE [BookID]=" + bookid;
    //                SqlCommand cmd = new SqlCommand(strcmd, con);
    //                SqlDataReader reader = cmd.ExecuteReader();
    //                if (reader.Read())
    //                {
    //                    string fpath = ConfigurationManager.AppSettings["Path"].ToString();
    //                    // Retrieve file data from the database
    //                    string filename = reader["title"].ToString();
    //                    string fextension = reader["fl_exten"].ToString();

    //                    string fname = filename + '.' + fextension;

    //                    string strPathFile = reader["File"].ToString();

    //                    // Set the appropriate content type based on the file extension
    //                    Response.ContentType = "application/pdf";

    //                    // Provide the file name for the download
    //                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + fname + ";");

    //                    // Write the file data to the response stream
    //                    Response.WriteFile(fpath + strPathFile, false);

    //                    Response.Flush();
    //                    // End the response
    //                    Response.End();
    //                }
    //                else
    //                {
    //                    // File not found in the database
    //                    Response.Write("File not found in the database.");
    //                }
    //            }

    //            catch (Exception ex)
    //            {
    //                Response.Write("Error: " + ex.Message);
    //            }
    //            finally
    //            {
    //                con.Close();
    //            }
    //        }
    //        else
    //        {
    //            // Handle case where Session["bookid"] is null
    //            Response.Write("Session variable 'bookid' is not set.");
    //        }
    //    }
    //    else
    //    {
    //        Response.Redirect("Login.aspx");
    //    }
    //}

    protected void databook_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        if (filePath != "")
        {
            e.Item.FindControl("downloadpnl").Visible = true;
            e.Item.FindControl("pnlopen").Visible = false;
        }
        else
        {
            e.Item.FindControl("downloadpnl").Visible = false;
            e.Item.FindControl("pnlopen").Visible = true;
        }
    }
    
}