﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void submitbtn_Click(object sender, EventArgs e)
    {
        ManageStudent objcls = new ManageStudent();
        objcls._txtName = txt_name.Text.Trim(); 
        objcls._email = txt_stu_email.Text.Trim();
        objcls._psswd = txt_psswd.Text.Trim();
        objcls._rollno = txt_rollno.Text.Trim();
        objcls._course = txt_course.Text.Trim();
        objcls._sem = txt_sem.Text.Trim();
        int res=objcls.createAC();
        if (res>0)
        {
            Response.Write("<script>alert('Create Account successfully...')</script>");
            Response.Redirect("Login.aspx");
            txt_name.Text = string.Empty;
            txt_stu_email.Text = string.Empty;
            txt_psswd.Text = string.Empty;
        }
    }
}