﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["stuID"]);
        if (id > 0)
        {
            loginpnl.Visible = false;
            profileshow.Visible = true;
        }
        else
        {
            loginpnl.Visible = true;
            profileshow.Visible = false;
        }
    }

    protected void logoutbtn_Click(object sender, EventArgs e)
    {
        long id = Convert.ToInt64(Session["stuID"]);
        SqlConnection con = new SqlConnection(clsEntity._Conn);
        string strUpTime = @"update [StuLibrary].[dbo].[tbl_stu_info] set [StuLogOutTime]=getdate() where [Stu_id]=" + id;
        SqlCommand sqlcmd = new SqlCommand(strUpTime, con);
        con.Open();
        int i = sqlcmd.ExecuteNonQuery();
        if (i > 0)
        {
            Response.Write("<script>alert('logout Time updated')</script>");
        }
        Session.Abandon();
        Response.Redirect("Login.aspx");

    }
}
